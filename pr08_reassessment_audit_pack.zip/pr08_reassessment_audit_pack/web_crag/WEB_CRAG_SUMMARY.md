# Web CRAG summary

Sources checked externally:

1. Planck PR4 statistical-isotropy work using 600 E2E simulations: supports requiring E2E calibration before CMB anomaly language. URL: https://arxiv.org/html/2504.05597v1
2. Cosmicflows-4 catalogue paper: confirms heterogeneous methods and group counts, so K5 must account for method/group/selection uncertainty. URL: https://arxiv.org/abs/2209.11238
3. Cosmicflows-4 velocity-field reconstruction: confirms Wiener filter + constrained realizations and lognormal-bias correction, so K6 posterior needs field realizations, not cellwise std draws. URL: https://arxiv.org/abs/2311.01340
4. Saadeh et al. Planck/Bianchi constraints: supports hard boundary that Bianchi-family claims need native morphology/transfer; scalar diagnostics are insufficient. URL: https://link.aps.org/doi/10.1103/PhysRevLett.117.131302
5. Tilted two-fluid Bianchi I stability: novelty should not be “tilted Bianchi I exists”; it should be moment-cone/scalar-nonsufficiency/observability. URL: https://arxiv.org/abs/2508.15155
