# Multiple-subagent review summary

## Cosmology/GR reviewer
- Accepts the restricted Bianchi-I moment and shear-memory mechanics as useful, but rejects generic “quadrupole forbids zero shear” wording outside closure/H3 assumptions.
- Requires `kappa=4/21` to be cited by exact equation/convention or kept symbolic.

## Statistics reviewer
- Accepts nuisance-projected rank only as local linear identifiability.
- Rejects K5 “release-matched” coverage as currently written; it is geometry+error matched Gaussian-prior mechanics.
- Accepts K1 max-scan mechanics but not E2E-calibrated significance.

## Data/OBSSTAT reviewer
- Accepts K6 curl-suppressed WF no-go, but not a physical vorticity posterior.
- Requires CF4 CR ensembles for posterior claims and realistic forward mocks for K5.

## Claim editor
- Main remaining problem is rhetoric: “honest publishable envelope,” “measured rank-2 comparator,” “EGS identity,” and “genuine Fisher-CR floor” outpace the evidence.

## Reproducibility reviewer
- Package tests pass (52/52).
- Report command list is stale and references missing files; this is a publication blocker for a self-contained evaluation package.
