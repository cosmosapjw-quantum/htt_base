#!/usr/bin/env python3
from pathlib import Path
import re, json, sys
ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path.cwd()
FILES=[ROOT/"docs/final_report/main.tex", ROOT/"docs/generated/egs_results_table.md", ROOT/"docs/research_program/BLOCKERS.md"]
PATTERNS={
 "anomaly_or_headline_overclaim": r"recovers the established low-\\ell CMB anomalies|honest publishable envelope|strong, honest joint result|measured rank-2 comparator",
 "stale_or_overstrong_theorem_name": r"Quadrupole-filling EGS identity|G_F=1 iff|floor nothing beats|forbids a vanishing shear-filling|strictly positive lower bound excludes zero",
 "synthetic_floor_overclaim": r"genuine multi-multipole Fisher--CR floor|genuine floor|strictly below",
 "data_discharge_overclaim": r"release-matched forward mocks|BLOCKED_MISSING_FIELD_REALIZATIONS.*discharged|CR ensemble is the posterior",
}
hits=[]
for f in FILES:
    if not f.exists(): continue
    for i,line in enumerate(f.read_text(errors='ignore').splitlines(),1):
        for k,pat in PATTERNS.items():
            if re.search(pat,line):
                hits.append({"file":str(f.relative_to(ROOT)),"line":i,"pattern":k,"text":line.strip()})
print(json.dumps({"hits":hits,"count":len(hits)}, indent=2, ensure_ascii=False))
sys.exit(1 if hits else 0)
