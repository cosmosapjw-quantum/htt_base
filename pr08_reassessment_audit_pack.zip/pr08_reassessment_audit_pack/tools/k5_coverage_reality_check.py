#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path.cwd()
p=ROOT/"docs/generated/k5_cf4_release_coverage.json"
obj=json.loads(p.read_text())
flags=[]
if obj.get("coverage",{}).get("sigma_cv_prior_kms_per_component") == 150.0:
    flags.append("uses fixed isotropic Gaussian bulk-flow prior sigma_cv=150 km/s/component")
if obj.get("config",{}).get("n_mock",0) < 1000:
    flags.append("mock count below robust tail-calibration target")
if obj.get("catalogue",{}).get("distance_error_model","").startswith("sigma_v"):
    flags.append("uses per-group distance-error model; no explicit Malmquist/grouping/selection forward model in artifact")
print(json.dumps({"status":"conditional_mechanics_not_full_release_mock" if flags else "ok", "flags":flags}, indent=2))
sys.exit(1 if flags else 0)
