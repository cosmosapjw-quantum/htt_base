#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT = Path(sys.argv[1]) if len(sys.argv)>1 else Path.cwd()
REQUIRED = [
"scripts/prove_egs_lowell_theorems.py",
"scripts/make_egs_lowell_theorem_figures.py",
"scripts/make_pr04_paper_figures.py",
"scripts/make_lowell_morphology_real_map.py",
"scripts/make_cf4_bulkflow_apex_depth.py",
"scripts/make_cf4_bulkflow_likelihood.py",
"scripts/make_cf4_affine_flow.py",
"scripts/generate_transfer_sensitivity_report.py",
"scripts/run_pr07_experiments.py",
"scripts/cove_verify_pr07.py",
"docs/generated/egs_lowell_theorem_proofs.json",
"docs/generated/pr04_paper_theorem_proofs.json",
"research_gates/pr04/tests",
]
missing=[p for p in REQUIRED if not (ROOT/p).exists()]
print(json.dumps({"missing":missing,"count":len(missing)}, indent=2))
sys.exit(1 if missing else 0)
