# Bundled planning context

This directory makes the Round-3 planning bundle understandable without any external local file paths.

- `reference/LONG_HORIZON_RESCUE_PR_ROADMAP_20260714.md`: formatting and governance reference for spec-first PR cards, decisive falsifiers, author/adjudicator separation and conjunctive gates.
- `reference/external_audit_research_report_v10.pdf`: current internal programme report used to localize terminology and research lanes.
- `round2/`: selected Round-2 legacy-revival planning documents and executable fixtures.  Round-3 does not silently import these modules; they are historical inputs and reusable test ideas.

The original 190-page legacy monograph and full legacy repositories are contained in the separate Round-2 self-contained package.  This Round-3 bundle includes only the context needed to execute its own PR roadmap and reference suite.
