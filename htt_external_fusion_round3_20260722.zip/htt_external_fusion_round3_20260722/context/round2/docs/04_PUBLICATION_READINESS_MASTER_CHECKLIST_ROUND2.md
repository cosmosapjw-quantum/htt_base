# Round-2 Publication Readiness Master Checklist

> 모든 항목은 conjunctive다. 해당 publication product에 적용되는 항목 하나라도 FAIL이면 제출하지 않는다.

## Definitions and mathematical objects

- [ ] PUB2-01: W2 tensor/vector conventions and MES conversion are one source of truth.
- [ ] PUB2-02: DeltaOmega_k is separated from PSTF spatial-curvature anisotropy.
- [ ] PUB2-03: Every component carries frame, epoch and units.
- [ ] PUB2-04: Acceleration/source state is not inserted into the Hamiltonian component cone.
- [ ] PUB2-05: xC is a projection of a complete DefectBundle, not the full state.
- [ ] PUB2-06: Residual/undeclared sectors are explicit.

## Theory and physical realizability

- [ ] PUB2-07: EGS premise lattice includes geodesic/acceleration and derivative assumptions.
- [ ] PUB2-08: Nilsson-type counterexamples are in the obstruction registry.
- [ ] PUB2-09: Joint comparator set is optimized over a common feasible model.
- [ ] PUB2-10: Sharpness stage is named algebraic/constraint/local/global.
- [ ] PUB2-11: MES coefficients have primary-source equation and independent derivation.
- [ ] PUB2-12: Multi-fluid flux, stress and frame transformations conserve total T_ab.

## Statistics

- [ ] PUB2-13: Observation and null scoring are exchangeable or cluster-valid.
- [ ] PUB2-14: Estimated covariance uncertainty is propagated.
- [ ] PUB2-15: Partial-ID coverage passes preregistered DGP grid.
- [ ] PUB2-16: Inactive normalized parameters leave evidence invariant.
- [ ] PUB2-17: Source discrimination contains systematic and superposition competitors.
- [ ] PUB2-18: Mandatory abstention fires for confusable/inadequate cases.
- [ ] PUB2-19: E-values have mean-one/conditional mean proof and predictable weights.

## Data and bridges

- [ ] PUB2-20: CF4 structural estimand and pipeline robustness set are separate.
- [ ] PUB2-21: Bulk-to-tilt bridge includes window and LSS covariance.
- [ ] PUB2-22: Planck masks/pipelines/null ensembles are matched.
- [ ] PUB2-23: DESI official mocks and random/window treatments are complete before attribution.
- [ ] PUB2-24: ACT application range and release simulations are validated.
- [ ] PUB2-25: Cosmic-dipole survey selection/clustering/systematics are explicit.

## Native solver — Track II

- [ ] PUB2-26: Real solver delivery receipt is native and independently audited.
- [ ] PUB2-27: FLRW null and Bianchi-I analytic benchmarks pass.
- [ ] PUB2-28: Recombination/reionization and Thomson collision are implemented.
- [ ] PUB2-29: Temperature and E/B parity benchmarks pass.
- [ ] PUB2-30: Multi-fluid energy-momentum conservation passes.
- [ ] PUB2-31: Response Jacobian has derivative and error-model cross-checks.
- [ ] PUB2-32: Morphology atlas covers family/orientation/handedness limits.

## Joint synthesis and release

- [ ] PUB2-33: Full comparator uses one common latent cosmology.
- [ ] PUB2-34: Cross-probe covariance and bridge uncertainty are included.
- [ ] PUB2-35: No marginal-branch Cartesian assembly is called an identified set.
- [ ] PUB2-36: All publication figures reproduce from clean checkout.
- [ ] PUB2-37: External hostile replication receipt is present.
- [ ] PUB2-38: Novelty, readiness and public-use states are all reported separately.
- [ ] PUB2-39: Every legacy result has a disposition and no retired result is active.
