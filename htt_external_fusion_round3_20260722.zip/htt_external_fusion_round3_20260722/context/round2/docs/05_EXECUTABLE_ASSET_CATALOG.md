# Executable Asset Catalog

모든 command는 package root에서 실행한다.

## `legacy_manifest_audit.py`

- **PR:** PR-209/214
- **목적:** legacy hashes, archive CRC and self-contained inventory
- **실행:** `python experiments/legacy_manifest_audit.py --out outputs/legacy_manifest_audit.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `defect_bundle_typecheck.py`

- **PR:** PR-210/212
- **목적:** frame/type and comparator validation
- **실행:** `python experiments/defect_bundle_typecheck.py --out outputs/defect_bundle_typecheck.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `inactive_parameter_evidence_invariance.py`

- **PR:** PR-214/220
- **목적:** inactive normalized prior invariance
- **실행:** `python experiments/inactive_parameter_evidence_invariance.py --out outputs/inactive_parameter_evidence_invariance.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `response_equivalence_quotient.py`

- **PR:** PR-219/236/238
- **목적:** response quotient and rank reopening
- **실행:** `python experiments/response_equivalence_quotient.py --out outputs/response_equivalence_quotient.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `joint_identified_set.py`

- **PR:** PR-215/240/243
- **목적:** joint feasible set versus marginal box
- **실행:** `python experiments/joint_identified_set.py --out outputs/joint_identified_set.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `finite_covariance_partial_id.py`

- **PR:** PR-225
- **목적:** precision bias and partial-ID coverage stress
- **실행:** `python experiments/finite_covariance_partial_id.py --out outputs/finite_covariance_partial_id.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `evalue_anytime.py`

- **PR:** PR-225
- **목적:** dependent merge and Ville crossing
- **실행:** `python experiments/evalue_anytime.py --out outputs/evalue_anytime.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `mes_attribution_surface.py`

- **PR:** PR-217
- **목적:** intrinsic-dipole attribution surface
- **실행:** `python experiments/mes_attribution_surface.py --out outputs/mes_attribution_surface.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `teff_surrogate_certification.py`

- **PR:** PR-218/239
- **목적:** surrogate error-domain certificate
- **실행:** `python experiments/teff_surrogate_certification.py --out outputs/teff_surrogate_certification.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `multi_fluid_flux_cancellation.py`

- **PR:** PR-223/235
- **목적:** flux cancellation and nonzero stress
- **실행:** `python experiments/multi_fluid_flux_cancellation.py --out outputs/multi_fluid_flux_cancellation.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `bulk_to_tilt_bridge.py`

- **PR:** PR-222/240
- **목적:** multi-window bridge rank and recovery
- **실행:** `python experiments/bulk_to_tilt_bridge.py --out outputs/bulk_to_tilt_bridge.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `cosmic_dipole_source_discrimination.py`

- **PR:** PR-221/243
- **목적:** source competitor and abstention battery
- **실행:** `python experiments/cosmic_dipole_source_discrimination.py --out outputs/cosmic_dipole_source_discrimination.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `directional_depth_falsifier.py`

- **PR:** PR-224
- **목적:** depth/host/direction falsifier
- **실행:** `python experiments/directional_depth_falsifier.py --out outputs/directional_depth_falsifier.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `legacy_mutation_suite.py`

- **PR:** PR-214
- **목적:** historical bad-claim detection
- **실행:** `python experiments/legacy_mutation_suite.py --out outputs/legacy_mutation_suite.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `bianchi_classification_audit.py`

- **PR:** PR-214/231
- **목적:** class A/B mutation audit
- **실행:** `python experiments/bianchi_classification_audit.py --out outputs/bianchi_classification_audit.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `solver_contract_validator.py`

- **PR:** PR-229+
- **목적:** interface PASS and real-native exit-3 blocking
- **실행:** `python experiments/solver_contract_validator.py --out outputs/solver_contract_validator.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `track_boundary_validator.py`

- **PR:** all
- **목적:** Track I/II DAG boundary validation
- **실행:** `python experiments/track_boundary_validator.py --out outputs/track_boundary_validator.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.

## `run_all.py`

- **PR:** package
- **목적:** run all Track-I assets and expected Track-II block
- **실행:** `python experiments/run_all.py --out outputs/run_all.json`
- **Exit:** 0 PASS, 2 scientific/mechanical FAIL. `solver_contract_validator.py --require-native`는 real solver가 없으면 의도된 exit 3.
