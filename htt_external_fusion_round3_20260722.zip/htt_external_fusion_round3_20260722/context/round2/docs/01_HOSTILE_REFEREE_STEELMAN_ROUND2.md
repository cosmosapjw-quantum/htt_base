# Round-2 Hostile Referee Steelman

> 모드: 가장 강한 반론을 구성한다. 단순 data-honesty 문구나 scope 축소로 해결되는 비판은 충분한 대응으로 인정하지 않는다.

## H2-01 — 원 프로젝트는 defect scalar 하나로 geometry를 압축해 비단사성과 cancellation을 숨긴다.

**최강 비판.** full metric/state inference가 가능한 것처럼 보였던 역사 자체가 programme의 기본 객체를 무효화한다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-02 — W2 normalization이 문서와 코드 사이에서 여러 차례 회귀했다.

**최강 비판.** 단일 scalar의 부호를 결정하는 계수조차 안정되지 않았다면 모든 downstream 수치가 의심스럽다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-03 — Omega_k,aniso는 scalar curvature difference이지 anisotropic curvature가 아니다.

**최강 비판.** 명명 오류가 tensor morphology와 scalar budget을 혼동시킨다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-04 — normal, matter, observer, electron congruence가 계산마다 섞인다.

**최강 비판.** 서로 다른 frame의 Sigma, W, tilt, curvature를 한 comparator에 더하는 것은 정의되지 않는다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-05 — acceleration을 Hamiltonian component처럼 다루는 old four-variable programme가 tensor role을 혼동한다.

**최강 비판.** Raychaudhuri/transport source와 energy-budget coordinate를 같은 cone에 넣을 수 없다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-06 — almost-EGS 논리는 derivative assumptions와 acceleration caveat를 누락하면 성립하지 않는다.

**최강 비판.** small CMB temperature는 small Weyl/geometry를 보장하지 않는다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-07 — product-box endpoint는 common Einstein–matter solution을 보장하지 않는다.

**최강 비판.** marginal ceilings 조립은 joint identified set이 아니다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-08 — endpoint sharpness의 PSD stream witness가 shear, vorticity, curvature의 GR 동역학적 실현을 증명하지 않는다.

**최강 비판.** abstract convex sharpness를 physical solution-space sharpness로 과대해석한다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-09 — MES vorticity·acceleration old coefficients와 universal hierarchy는 source provenance가 닫히지 않았다.

**최강 비판.** byte-frozen 값은 문헌 근거가 아니다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-10 — epsilon1=0 attribution은 이상적 branch이지 intrinsic dipole이 정확히 0이라는 관측 결론이 아니다.

**최강 비판.** ceiling tightening이 branch 선택에 지배된다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-11 — Teff universal ratios는 reduced ansatz artefact일 수 있다.

**최강 비판.** native transfer에 대한 오차 bound 없이 physical correction으로 사용할 수 없다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-12 — old BASS의 10^14 transfer mismatch를 cascade enhancement로 해석한 것은 검증이 아니라 합리화다.

**최강 비판.** independent Boltzmann solution 없이 absolute response를 신뢰할 수 없다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-13 — legacy Bianchi classification table에는 VI0/VIIh class 오류가 있었다.

**최강 비판.** family atlas와 downstream rules가 손상됐다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-14 — zero columns를 미리 넣은 design의 rank-two 결과는 tautology다.

**최강 비판.** physical response Jacobian이 아닌 hand-designed surrogate rank다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-15 — old evidence는 scalar dipole amplitude를 geometry evidence로 오독했다.

**최강 비판.** observational duplicates와 inactive parameters가 family ranking을 무효화한다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-16 — inactive normalized parameter가 Occam penalty를 만든다는 old 해석은 수학적으로 틀렸다.

**최강 비판.** evidence 차이는 hidden model/prior/numerical difference다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-17 — CatWISE, radio, CMB, CF4를 공통 beta 하나로 묶은 model은 source/systematic 구조를 삭제한다.

**최강 비판.** large Bayes factor는 geometry가 아니라 forced common amplitude를 측정한다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-18 — finite-volume CF4 bulk flow는 homogeneous matter tilt가 아니다.

**최강 비판.** window, LSS stochastic flow, calibration을 거치지 않은 bridge는 invalid하다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-19 — CF4 bulk estimator uncertainty가 survey geometry와 nonlinear velocities에 민감하다.

**최강 비판.** 단일 amplitude tension은 estimator/covariance artefact일 수 있다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-20 — cosmic dipole anomaly는 survey selection, clustering, overdispersion, common systematics와 얽힌다.

**최강 비판.** shared cosmological source를 우선시하면 source discrimination이 circular하다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-21 — Planck finite-null ranks는 noise reuse와 scorer asymmetry가 있으면 exact exchangeability가 아니다.

**최강 비판.** p-value exactness를 과장할 수 있다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-22 — estimated covariance, weak ID와 nonlinear endpoint에서 nominal coverage가 보장되지 않는다.

**최강 비판.** toy Gaussian coverage를 data confidence로 승격한다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-23 — multi-fluid tilt를 one-beta effective fluid로 축약하면 flux cancellation과 anisotropic stress를 잃는다.

**최강 비판.** solver의 species dynamics와 comparator가 분리되지 않는다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-24 — Tsagas/H0/peculiar Jeans old percentages는 bulk amplitude를 velocity divergence로 치환했다.

**최강 비판.** point velocity가 first jet을 결정하지 않는다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-25 — BASS/HTT/MIO claim governance가 self-certification에 머물 수 있다.

**최강 비판.** 같은 팀의 gate 통과는 외부 검증이 아니다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-26 — legacy test count는 import/path 오류와 self-oracle 때문에 scientific validation이 아니다.

**최강 비판.** green CI가 incorrect physics를 고정할 수 있다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-27 — native solver track이 interface만 맞추고 실제 temperature/polarization physics를 검증하지 않을 수 있다.

**최강 비판.** 형식적 delivery가 family claims를 부당하게 여는 위험이 있다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-28 — Teff emulator가 native solver outputs로 학습·검증될 때 split이 잘못되면 circular validation이다.

**최강 비판.** surrogate error가 과소평가된다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-29 — full comparator assembly가 MES, CF4, LRS curvature ceilings의 서로 다른 premise를 곱한다.

**최강 비판.** common latent cosmology가 없으면 full result가 아니다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-30 — Track I와 Track II가 느슨하면 pre-solver result가 solver-dependent morphology claim을 우회한다.

**최강 비판.** native boundary가 문서가 아니라 DAG로 강제돼야 한다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-31 — programme가 너무 넓어 한 편의 논문도 완결하지 못할 수 있다.

**최강 비판.** 통합 야심이 incomplete lanes의 집합으로 끝날 위험이 있다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.

## H2-32 — 과거 오류를 archive에만 보존하면 동일 오류가 다시 production으로 들어올 수 있다.

**최강 비판.** historical archaeology가 executable mutation corpus로 전환돼야 한다.

**Referee demand.** 원 claim의 범위와 강도를 유지하려면 반례를 제거하는 새 정리·forward model·calibration 또는 독립 재현을 제시해야 한다. 문구 수정만으로는 close할 수 없다.
