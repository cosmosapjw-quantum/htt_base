# Package Validation

## Mechanical validation

- `python -m pytest -q`: **9 passed**.
- Track-I executable assets: **16/16 PASS**.
- SymPy proof witnesses: **5/5 PASS**.
- Track-II native scientific gate: **EXPECTED_BLOCK**, exit code 3 on the included synthetic interface fixture.
- Proposed PRs: **38** = Track I 20 + Track II 14 + Integration 4.
- Hostile/advocate pairs: **32/32 mapped**.
- PR PASS gates: **208**; FAIL/kill gates: **132**.

## Reference synthetic results

These are code-validation fixtures, not observational results.

- Multi-survey source discrimination: overall correct/abstain-target rate `0.9073`; misspecified/confusable scenario abstention `1.0000`.
- Finite-covariance precision stress: naive mean inflation `1.1699`, Hartlap-corrected `0.9990`.
- Common-feasible comparator width ratio versus marginal product box: `0.1818`.
- MES attribution surface: W2 ceiling changes from `3.3796e-13` at intrinsic epsilon1=0 to `2.8173e-05` under full-dipole attribution.
- Teff surrogate fixture: in-domain maximum error `1.5454e-06` under certified envelope `1.7488e-06`; out-of-domain rejection is live.
- Bulk-to-tilt bridge fixture: single-window rank `1`, multi-window rank `3`, recovery bias norm `0.0112`.

## Interpretation

PASS means the self-contained planning/reference package executes consistently. It does not close any proposed scientific PR. Track II remains intentionally blocked until a real native Bianchi Boltzmann solver delivery is supplied.
