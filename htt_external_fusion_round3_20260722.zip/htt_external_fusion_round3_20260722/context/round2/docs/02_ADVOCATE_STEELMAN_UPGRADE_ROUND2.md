# Round-2 Advocate Steelman Upgrade

> 원 야심을 낮추지 않는다. 각 비판을 더 일반적이고 강한 theorem, model 또는 falsifiable experiment로 전환한다.

## A2-01 ↔ H2-01 — scalar를 버리지 않고 typed DefectBundle의 projection으로 격상한다.

**직접 대응.** frame, epoch, source sector, admissible class, response와 identified object를 포함한 bundle을 공식 state로 삼고 xC는 support functional로 정의한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-02 ↔ H2-02 — W2 normalization을 parent constraint에서 유일하게 유도하고 source scan을 kill gate로 만든다.

**직접 대응.** tensor/vector dual identity와 MES conversion을 한 seal로 묶어 모든 report/code/figure를 자동 생성한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-03 ↔ H2-03 — DeltaOmega_k와 genuine PSTF 3-Ricci sector를 동시에 도입한다.

**직접 대응.** scalar budget departure와 tensor curvature morphology를 분리한 뒤 solver가 둘 사이 response를 제공하게 한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-04 ↔ H2-04 — congruence-indexed comparator functor를 증명한다.

**직접 대응.** Sigma_F, W_F, R3_F를 frame-index하고 bridge 없는 cross-frame arithmetic을 type error로 만든다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-05 ↔ H2-05 — acceleration을 source-sector state로 승격한다.

**직접 대응.** Hamiltonian bundle과 Raychaudhuri/radiation-source bundle을 결합하는 typed evolution graph를 만든다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-06 ↔ H2-06 — EGS premise lattice와 counterexample atlas를 programme의 이론 중심으로 만든다.

**직접 대응.** geodesic/accelerating, exact/almost, derivative-complete/incomplete branches를 모두 정리하고 obstruction을 정량화한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-07 ↔ H2-07 — box theorem을 general joint support theorem으로 확장한다.

**직접 대응.** Einstein constraints, common nuisance와 bridge equations를 포함한 feasible set 위에서 xC를 직접 최적화한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-08 ↔ H2-08 — physical sharpness를 constraint, local development, global solution의 3단계 정리로 완성한다.

**직접 대응.** 각 endpoint의 explicit initial data와 evolution certificate를 요구한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-09 ↔ H2-09 — MES를 source-exact branch algebra로 재건한다.

**직접 대응.** accessible geodesic, recovered non-geodesic, acceleration branch를 별도 theorem ID와 provenance로 관리한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-10 ↔ H2-10 — intrinsic dipole를 parameterized attribution surface로 만든다.

**직접 대응.** epsilon1_intrinsic에 따른 ceilings와 modern CMB constraints를 joint likelihood/identified set으로 계산한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-11 ↔ H2-11 — Teff를 certified reduced-order model로 바꾼다.

**직접 대응.** native solver와 held-out design에서 whitened error envelope를 증명하고 domain 밖에서는 fail한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-12 ↔ H2-12 — 10^14 mismatch를 solver challenge benchmark로 승격한다.

**직접 대응.** old transfer가 실패하도록 고정하고 native solver가 absolute/relative limits를 통과해야 한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-13 ↔ H2-13 — structure constants에서 11-type atlas를 clean-room 생성한다.

**직접 대응.** Jacobi, class A/B, Ricci, FLRW limit와 parity를 exact engines로 재도출한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-14 ↔ H2-14 — surrogate design rank를 native physical response Jacobian으로 업그레이드한다.

**직접 대응.** finite-difference/autodiff response와 emulator uncertainty를 포함해 observable set별 quotient lattice를 만든다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-15 ↔ H2-15 — old evidence를 adversarial benchmark로 유지하고 source-discrimination likelihood를 새로 만든다.

**직접 대응.** geometry posterior는 morphology response가 열릴 때만 허용한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-16 ↔ H2-16 — inactive-parameter invariance를 release gate로 만든다.

**직접 대응.** normalized prior 아래 evidence equality를 analytic and stochastic engines에서 확인한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-17 ↔ H2-17 — multi-survey latent-source model을 구축한다.

**직접 대응.** kinematic, local LSS, survey systematics, shared global source와 superposition을 경쟁시키고 non-ID에서 abstain한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-18 ↔ H2-18 — bulk-to-tilt stochastic bridge를 field level로 증명한다.

**직접 대응.** multi-window operator, LSS covariance, selection/calibration nuisance와 depth coherence를 포함한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-19 ↔ H2-19 — CF4 structural estimand과 pipeline robustness set을 분리한다.

**직접 대응.** vector-level coverage와 realistic mocks를 통과한 set만 physical bridge에 연결한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-20 ↔ H2-20 — cosmic dipole source discrimination을 survey response matrix problem으로 만든다.

**직접 대응.** redshift/tracer/frequency windows와 common latent systematics를 모델링해 source rank를 계산한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-21 ↔ H2-21 — cluster-exchangeable or independently trained finite-null inference를 완성한다.

**직접 대응.** observation/simulation score symmetry와 noise-cluster calibration을 증명한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-22 ↔ H2-22 — estimated-covariance partial-ID theorem과 bootstrap/t-likelihood를 개발한다.

**직접 대응.** active boundary와 nonlinear norm에 대해 uniform/grid-conditional coverage를 명시한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-23 ↔ H2-23 — species-resolved multi-fluid atlas를 만든다.

**직접 대응.** rho_s,p_s,u_s,q_s,pi_s와 collision terms를 solver interface로 고정한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-24 ↔ H2-24 — Tsagas programme를 divergence-based falsifier로 강화한다.

**직접 대응.** direction x depth x host-property를 동시에 예측하는 field-level test를 구현한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-25 ↔ H2-25 — claim gate를 외부 adjudication 가능한 proof-carrying promotion system으로 강화한다.

**직접 대응.** novelty와 readiness를 분리하면서 public use에는 독립 receipt를 필수화한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-26 ↔ H2-26 — legacy tests를 known-bad mutation laboratory로 전환한다.

**직접 대응.** factor-three, class swap, inactive Occam, frame bridge와 transfer mismatch를 반드시 kill한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-27 ↔ H2-27 — solver delivery를 physics contract로 만든다.

**직접 대응.** FLRW null, Bianchi I analytic transfer, recombination/reionization, E/B parity, convergence와 independent oracle를 conjunctive gate로 둔다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-28 ↔ H2-28 — surrogate calibration을 nested train/calibration/challenge split과 domain coverage로 인증한다.

**직접 대응.** native solver release hash와 challenge holdout을 certificate에 묶는다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-29 ↔ H2-29 — common latent cosmology joint model을 실제로 구축한다.

**직접 대응.** 동일 frame/epoch/species/dynamics가 CMB, velocities, counts와 lensing을 동시에 생성하게 한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-30 ↔ H2-30 — Track I/II boundary를 machine-validated DAG로 강제한다.

**직접 대응.** Track I node가 solver receipt 또는 Track II artifact에 의존하면 CI가 실패한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-31 ↔ H2-31 — 넓은 programme를 세 publication products로 동시에 완결한다.

**직접 대응.** Track I methods/data, Track II solver/theory, joint synthesis를 독립 release units로 관리한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.

## A2-32 ↔ H2-32 — 모든 역사적 오류를 executable regression mutation으로 보존한다.

**직접 대응.** 새 implementation이 old claim을 재생하면 release를 즉시 차단한다.

**강화된 종료조건.** 기존 claim을 보존하는 수준이 아니라, 반론의 domain까지 포함하는 successor claim과 decisive falsifier가 모두 구현돼야 한다.
