# Legacy Revival Round-2: Dual-Track Long-Horizon Research PR Roadmap

- **문서 상태:** `PROPOSED_ONLY_NOT_IN_ACTIVE_DAG`
- **작성일:** 2026-07-21
- **Owner:** `COMMON`
- **Implementation scope:** `research_program_planning`
- **Novelty axis:** external-literature adjudication, internal readiness와 독립
- **Public use:** `false`
- **Input authority:** 이 zip 내부 `legacy_sources/`, `context/`, `prior_round1/`
- **Track-I rule:** native Bianchi Boltzmann solver output을 절대 요구하거나 소비하지 않는다.
- **Track-II rule:** real native `SolverDeliveryReceipt`가 없으면 모든 scientific command는 exit 3 `BLOCKED_NATIVE_REQUIRED`.
- **Integration rule:** PR-243 이후는 Track-I checkpoint PR-228과 Track-II checkpoint PR-242가 모두 통과해야 한다.

## 1. 목적과 판정 원칙

이 로드맵은 구 프로젝트의 범위를 줄이지 않는다. scalar defect, cosmic dipole, CF4, MES, Teff, Bianchi family와 multi-probe programme를 더 강한 typed state, source-specific branch, stochastic bridge와 native transfer로 재건한다. `Literal rescue`, `corrected supersession`, `rebuild`, `blocked`를 구분하며, author가 자기 결과를 자동 promote할 수 없다.

모든 PR은 구현 전에 SPEC, decisive falsifier와 pass/fail gate를 고정한다. PASS는 conjunctive다. 한 개의 P0 gate도 다른 성공으로 상쇄되지 않는다.

## 2. Track DAG

```text
TRACK I (209–228) ───────────┐
                             ├─ PR-243–246 Integration
TRACK II (229–242, native) ──┘
```

Track I에서 Track II로 향하는 dependency는 허용되지만, Track I node가 Track II output을 소비하는 역방향 dependency는 금지한다. Track II는 PR-229 native delivery gate 이후에만 열린다.

## 3. 공통 실행 계약

1. SPEC 이전에 observed result를 계산하지 않는다.
2. frame/order/domain/units, data population, null/covariance, nuisance/prior와 transfer source를 명시한다.
3. author와 adjudicator principal을 분리한다.
4. 실패·non-identification·BLOCKED도 정상 연구 산출물로 보존한다.
5. legacy source는 직접 import하지 않고 clean-room successor 또는 mutation fixture로만 사용한다.
6. novelty tier는 readiness를 자동 승격하지 않지만, 내부 OPEN 상태만으로 external novelty를 자동 강등하지도 않는다.
7. 단순 문구 완화는 scientific remediation으로 세지 않는다.

## 4. PR 카드

### PR-209 — Round-2 intake, immutable legacy inventory and disposition graph

- **Track / dependencies / cost / risk:** `I` / none / `medium` / `medium`.
- **Hostile findings:** H2-25, H2-26, H2-32.
- **강화 목표 claim:** 모든 legacy artifact를 immutable, hash-bound research object로 만들고 각 symbol을 KEEP/REBUILD/MUTATION/RETIRE로 판정한다.
- **Decisive falsifier:** legacy archive member, hash 또는 disposition 하나를 삭제/변경해도 verifier가 green인 경우.
- **실제로 할 것:** archive CRC/hash inventory, curated extraction, disposition DAG와 no-direct-import scanner를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/legacy_manifest_audit.py` — `python experiments/legacy_manifest_audit.py`
  - `fixtures/legacy_disposition_seed.yaml` — `read/reference fixtures/legacy_disposition_seed.yaml`
- **PASS gates:**
  - [ ] PR-209-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-209-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-209-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-209-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-209-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-209-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-209-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-209-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** 모든 legacy artifact를 immutable, hash-bound research object로 만들고 각 symbol을 KEEP/REBUILD/MUTATION/RETIRE로 판정한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-210 — BASS–HTT–MIO constitution and typed DefectBundle

- **Track / dependencies / cost / risk:** `I` / PR-209 / `medium` / `high`.
- **Hostile findings:** H2-01, H2-05, H2-29.
- **강화 목표 claim:** 원 프로젝트의 통합 야심을 typed defect state, response와 identified object의 구성으로 재정립한다.
- **Decisive falsifier:** 서로 다른 frame/epoch의 component를 bridge 없이 더했는데 bundle validator가 허용하는 경우.
- **실제로 할 것:** DefectBundle, SourceState, BridgeReceipt와 owner interface를 production schema로 이식한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `revival_core/revival_core/types.py` — `python revival_core/revival_core/types.py`
  - `experiments/defect_bundle_typecheck.py` — `python experiments/defect_bundle_typecheck.py`
  - `schemas/defect_bundle.schema.json` — `read/reference schemas/defect_bundle.schema.json`
- **PASS gates:**
  - [ ] PR-210-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-210-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-210-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-210-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-210-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-210-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-210-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-210-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** 원 프로젝트의 통합 야심을 typed defect state, response와 identified object의 구성으로 재정립한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-211 — Constraint-natural conventions and signed curvature split

- **Track / dependencies / cost / risk:** `I` / PR-210 / `medium` / `medium`.
- **Hostile findings:** H2-02, H2-03.
- **강화 목표 claim:** W2 convention uniqueness와 scalar DeltaOmega_k/tensor 3-Ricci PSTF 분리를 공식 정리로 만든다.
- **Decisive falsifier:** omega-vector form이 tensor form과 3배 차이나거나 DeltaOmega_k가 PSD magnitude로 강제돼도 gate가 통과하는 경우.
- **실제로 할 것:** parent constraint derivation, convention source scan, curvature carrier type과 migration을 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `proofs/sympy/w2_normalization_seal.py` — `python proofs/sympy/w2_normalization_seal.py`
  - `proofs/sympy/defect_identity_seal.py` — `python proofs/sympy/defect_identity_seal.py`
  - `legacy_sources/patched/htt/ssot.py` — `python legacy_sources/patched/htt/ssot.py`
- **PASS gates:**
  - [ ] PR-211-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-211-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-211-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-211-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-211-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-211-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-211-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-211-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** W2 convention uniqueness와 scalar DeltaOmega_k/tensor 3-Ricci PSTF 분리를 공식 정리로 만든다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-212 — Congruence-indexed frame and rest-space curvature type system

- **Track / dependencies / cost / risk:** `I` / PR-210, PR-211 / `medium` / `medium`.
- **Hostile findings:** H2-04, H2-05.
- **강화 목표 claim:** normal/matter/observer/electron frame component와 vortical rest-bundle curvature를 명시적 functor로 다룬다.
- **Decisive falsifier:** vortical congruence의 orthogonal hypersurface curvature 또는 n-frame shear와 u-frame W2가 bridge 없이 조립되는 경우.
- **실제로 할 것:** frame-indexed symbol registry, Frobenius gate와 Gauss-contraction convention을 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/defect_bundle_typecheck.py` — `python experiments/defect_bundle_typecheck.py`
  - `docs/08_TRACK_BOUNDARY_AND_SOLVER_HANDOFF_CONTRACT.md` — `read/reference docs/08_TRACK_BOUNDARY_AND_SOLVER_HANDOFF_CONTRACT.md`
- **PASS gates:**
  - [ ] PR-212-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-212-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-212-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-212-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-212-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-212-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-212-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-212-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** normal/matter/observer/electron frame component와 vortical rest-bundle curvature를 명시적 functor로 다룬다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-213 — External novelty × internal readiness × promotion state machine

- **Track / dependencies / cost / risk:** `I` / PR-209 / `medium` / `high`.
- **Hostile findings:** H2-25.
- **강화 목표 claim:** novelty S/readiness OPEN을 허용하되 public use는 proof-carrying external adjudication으로만 연다.
- **Decisive falsifier:** novelty가 높다는 이유만으로 public_use가 true가 되는 경우.
- **실제로 할 것:** dual-axis claim schema, transition proofs, author/adjudicator inequality와 publication builder guard를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `revival_core/revival_core/claim_state.py` — `python revival_core/revival_core/claim_state.py`
  - `legacy_sources/patched/mio/status_schema.py` — `python legacy_sources/patched/mio/status_schema.py`
  - `prior_round1/experiments/dual_axis_claim_validator.py` — `python prior_round1/experiments/dual_axis_claim_validator.py`
- **PASS gates:**
  - [ ] PR-213-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-213-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-213-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-213-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-213-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-213-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-213-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-213-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** novelty S/readiness OPEN을 허용하되 public use는 proof-carrying external adjudication으로만 연다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-214 — Hermetic legacy mutation laboratory and clean-room replay

- **Track / dependencies / cost / risk:** `I` / PR-209, PR-211, PR-213 / `medium` / `medium`.
- **Hostile findings:** H2-13, H2-16, H2-26, H2-32.
- **강화 목표 claim:** 과거의 틀린 결과를 지우지 않고 모든 future implementation을 공격하는 mutation corpus로 만든다.
- **Decisive falsifier:** factor-three, VI0/VIIh swap, inactive Occam, local=global bridge 중 하나가 살아남는 경우.
- **실제로 할 것:** known-bad fixtures, clean CWD import/replay, no direct legacy import와 mutation kill matrix를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/legacy_mutation_suite.py` — `python experiments/legacy_mutation_suite.py`
  - `experiments/bianchi_classification_audit.py` — `python experiments/bianchi_classification_audit.py`
  - `experiments/inactive_parameter_evidence_invariance.py` — `python experiments/inactive_parameter_evidence_invariance.py`
- **PASS gates:**
  - [ ] PR-214-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-214-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-214-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-214-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-214-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-214-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-214-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-214-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** 과거의 틀린 결과를 지우지 않고 모든 future implementation을 공격하는 mutation corpus로 만든다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-215 — General joint feasible-set support theorem

- **Track / dependencies / cost / risk:** `I` / PR-210, PR-211, PR-212 / `high` / `medium`.
- **Hostile findings:** H2-07, H2-29.
- **강화 목표 claim:** full comparator interval을 arbitrary common feasible set의 support image로 계산하고 product box를 corollary로 내린다.
- **Decisive falsifier:** coupled feasible manifold보다 marginal box interval을 sharp라고 보고하는 경우.
- **실제로 할 것:** convex/nonconvex set engine, common nuisance constraints와 independent solver cross-check를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/joint_identified_set.py` — `python experiments/joint_identified_set.py`
  - `revival_core/revival_core/comparator.py` — `python revival_core/revival_core/comparator.py`
- **PASS gates:**
  - [ ] PR-215-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-215-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-215-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-215-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-215-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-215-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-215-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-215-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** full comparator interval을 arbitrary common feasible set의 support image로 계산하고 product box를 corollary로 내린다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-216 — Physical sharpness ladder: algebraic → constraint → local → global

- **Track / dependencies / cost / risk:** `I` / PR-212, PR-215 / `high` / `high`.
- **Hostile findings:** H2-08.
- **강화 목표 claim:** sharpness를 약화하지 않고 실제 Einstein–matter solution-space endpoint attainability까지 단계별로 증명하는 programme를 연다.
- **Decisive falsifier:** algebraic PSD witness만으로 global dynamics sharpness가 자동 승격되는 경우.
- **실제로 할 것:** proof-stage schema, constraint residual oracle, local-development obligations와 blocked global stage를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `docs/06_THEOREM_PROOF_BACKLOG_ROUND2.md` — `read/reference docs/06_THEOREM_PROOF_BACKLOG_ROUND2.md`
  - `proofs/sympy/multi_fluid_moment_seal.py` — `python proofs/sympy/multi_fluid_moment_seal.py`
- **PASS gates:**
  - [ ] PR-216-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-216-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-216-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-216-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-216-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-216-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-216-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-216-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** sharpness를 약화하지 않고 실제 Einstein–matter solution-space endpoint attainability까지 단계별로 증명하는 programme를 연다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-217 — MES primary-source branch reconstruction and attribution surface

- **Track / dependencies / cost / risk:** `I` / PR-211, PR-212, PR-214 / `high` / `medium`.
- **Hostile findings:** H2-09, H2-10.
- **강화 목표 claim:** MES를 geodesic/non-geodesic/acceleration branch의 source-exact hierarchy로 완성한다.
- **Decisive falsifier:** source equation 없는 coefficient가 live ceiling으로 들어가거나 epsilon1=0이 유일성 정리로 표시되는 경우.
- **실제로 할 것:** primary-source archive, independent reduction, attribution surface와 uncertainty component ontology를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/mes_attribution_surface.py` — `python experiments/mes_attribution_surface.py`
  - `legacy_sources/patched/htt/bounds.py` — `python legacy_sources/patched/htt/bounds.py`
- **PASS gates:**
  - [ ] PR-217-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-217-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-217-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-217-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-217-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-217-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-217-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-217-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** MES를 geodesic/non-geodesic/acceleration branch의 source-exact hierarchy로 완성한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-218 — Teff/BASS-lite certified surrogate programme

- **Track / dependencies / cost / risk:** `I` / PR-209, PR-210, PR-214 / `medium` / `medium`.
- **Hostile findings:** H2-11, H2-12, H2-28.
- **강화 목표 claim:** Teff를 폐기하지 않고 domain-certified reduced-order model이 되기 위한 solver-independent contract와 synthetic methodology를 완성한다.
- **Decisive falsifier:** training points와 calibration points가 겹치거나 domain 밖 output이 inference로 통과하는 경우.
- **실제로 할 것:** surrogate certificate, nested splits, error envelope, old 10^14 mismatch challenge fixture를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/teff_surrogate_certification.py` — `python experiments/teff_surrogate_certification.py`
  - `legacy_sources/patched/bass/surrogate_contract.py` — `python legacy_sources/patched/bass/surrogate_contract.py`
- **PASS gates:**
  - [ ] PR-218-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-218-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-218-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-218-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-218-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-218-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-218-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-218-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** Teff를 폐기하지 않고 domain-certified reduced-order model이 되기 위한 solver-independent contract와 synthetic methodology를 완성한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-219 — Pre-solver response quotient and non-identification atlas

- **Track / dependencies / cost / risk:** `I` / PR-210, PR-212, PR-215 / `medium` / `high`.
- **Hostile findings:** H2-14, H2-15.
- **강화 목표 claim:** family labels를 declared surrogate response의 quotient로 정확히 분류하고 reopening observable requirements를 계산한다.
- **Decisive falsifier:** zero column을 물리적 no-go로 쓰거나 equivalent families를 별도 evidence rows로 ranking하는 경우.
- **실제로 할 것:** response class API, rank lattice, null/prior-exposure report와 quotient visualizer를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/response_equivalence_quotient.py` — `python experiments/response_equivalence_quotient.py`
  - `legacy_sources/patched/mio/equivalence.py` — `python legacy_sources/patched/mio/equivalence.py`
- **PASS gates:**
  - [ ] PR-219-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-219-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-219-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-219-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-219-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-219-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-219-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-219-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** family labels를 declared surrogate response의 quotient로 정확히 분류하고 reopening observable requirements를 계산한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-220 — Legacy evidence as adversarial benchmark and coherent evidence invariance

- **Track / dependencies / cost / risk:** `I` / PR-214, PR-219 / `medium` / `medium`.
- **Hostile findings:** H2-15, H2-16, H2-17.
- **강화 목표 claim:** old lnB pipeline을 negative control로 사용해 inactive invariance와 source/model equivalence를 강제한다.
- **Decisive falsifier:** inactive normalized parameter 추가가 log evidence를 tolerance 이상 바꾸거나 duplicate response가 geometry preference를 만드는 경우.
- **실제로 할 것:** analytic evidence fixture, two-engine small models, old likelihood replay with expected failure status를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/inactive_parameter_evidence_invariance.py` — `python experiments/inactive_parameter_evidence_invariance.py`
  - `proofs/sympy/inactive_prior_invariance.py` — `python proofs/sympy/inactive_prior_invariance.py`
- **PASS gates:**
  - [ ] PR-220-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-220-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-220-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-220-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-220-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-220-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-220-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-220-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** old lnB pipeline을 negative control로 사용해 inactive invariance와 source/model equivalence를 강제한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-221 — Cross-survey latent cosmic-dipole source discrimination

- **Track / dependencies / cost / risk:** `I` / PR-213, PR-219, PR-220 / `high` / `medium`.
- **Hostile findings:** H2-17, H2-20.
- **강화 목표 claim:** kinematic, LSS, survey systematic, shared global source와 superposition을 모두 포함해 cosmic dipole origin을 직접 식별한다.
- **Decisive falsifier:** confusable/misspecified source에서 mandatory abstention 없이 global source가 선택되는 경우.
- **실제로 할 것:** survey response matrix, hierarchical covariance, held-out prediction와 source-rank/abstention battery를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/cosmic_dipole_source_discrimination.py` — `python experiments/cosmic_dipole_source_discrimination.py`
- **PASS gates:**
  - [ ] PR-221-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-221-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-221-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-221-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-221-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-221-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-221-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-221-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** kinematic, LSS, survey systematic, shared global source와 superposition을 모두 포함해 cosmic dipole origin을 직접 식별한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-222 — Finite-window stochastic bulk-flow to homogeneous-tilt bridge

- **Track / dependencies / cost / risk:** `I` / PR-210, PR-212, PR-219 / `high` / `high`.
- **Hostile findings:** H2-18, H2-19.
- **강화 목표 claim:** CF4와 homogeneous tilt의 관계를 point substitution이 아니라 multi-window stochastic forward operator로 증명한다.
- **Decisive falsifier:** single bulk amplitude만으로 3D homogeneous tilt가 point identified되는 경우.
- **실제로 할 것:** window operators, LSS covariance, calibration/selection nuisance, depth coherence와 rank theorem을 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/bulk_to_tilt_bridge.py` — `python experiments/bulk_to_tilt_bridge.py`
  - `proofs/sympy/bulk_bridge_rank.py` — `python proofs/sympy/bulk_bridge_rank.py`
- **PASS gates:**
  - [ ] PR-222-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-222-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-222-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-222-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-222-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-222-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-222-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-222-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** CF4와 homogeneous tilt의 관계를 point substitution이 아니라 multi-window stochastic forward operator로 증명한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-223 — Species-resolved multi-fluid moment and frame atlas

- **Track / dependencies / cost / risk:** `I` / PR-210, PR-212 / `medium` / `medium`.
- **Hostile findings:** H2-05, H2-23.
- **강화 목표 claim:** single-beta programme를 species-resolved moment hierarchy로 확장한다.
- **Decisive falsifier:** zero net flux가 zero tilt energy 또는 zero anisotropic stress로 처리되는 경우.
- **실제로 할 것:** SpeciesState, antipodal/multi-stream moment cone, flux cancellation와 solver handoff schema를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/multi_fluid_flux_cancellation.py` — `python experiments/multi_fluid_flux_cancellation.py`
  - `proofs/sympy/multi_fluid_moment_seal.py` — `python proofs/sympy/multi_fluid_moment_seal.py`
- **PASS gates:**
  - [ ] PR-223-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-223-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-223-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-223-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-223-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-223-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-223-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-223-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** single-beta programme를 species-resolved moment hierarchy로 확장한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-224 — Directional × depth × host-property falsifier programme

- **Track / dependencies / cost / risk:** `I` / PR-212, PR-222 / `medium` / `medium`.
- **Hostile findings:** H2-24.
- **강화 목표 claim:** old Tsagas/H0 programme를 포기하지 않고 velocity first-jet와 scale-dependent falsifier로 강화한다.
- **Decisive falsifier:** bulk amplitude를 divergence로 직접 치환하거나 depth scaling 없이 H0 percentage를 보고하는 경우.
- **실제로 할 것:** divergence/shear/curl field modes, host covariates와 preregistered competing scalings를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/directional_depth_falsifier.py` — `python experiments/directional_depth_falsifier.py`
- **PASS gates:**
  - [ ] PR-224-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-224-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-224-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-224-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-224-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-224-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-224-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-224-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** old Tsagas/H0 programme를 포기하지 않고 velocity first-jet와 scale-dependent falsifier로 강화한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-225 — Estimated-covariance partial identification and anytime evidence

- **Track / dependencies / cost / risk:** `I` / PR-215, PR-219, PR-220 / `high` / `high`.
- **Hostile findings:** H2-21, H2-22.
- **강화 목표 claim:** finite covariance, weak ID, nonlinear endpoints와 staged data를 동시에 다루는 calibrated inference layer를 완성한다.
- **Decisive falsifier:** nominal 95% coverage lower bound가 gate 아래거나 reused cluster를 iid exact로 표시하는 경우.
- **실제로 할 것:** Hotelling/t likelihood, bootstrap endpoint, cluster rank, e-value merge와 DGP-grid coverage를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/finite_covariance_partial_id.py` — `python experiments/finite_covariance_partial_id.py`
  - `experiments/evalue_anytime.py` — `python experiments/evalue_anytime.py`
  - `prior_round1/experiments/cluster_exchangeable_rank.py` — `python prior_round1/experiments/cluster_exchangeable_rank.py`
- **PASS gates:**
  - [ ] PR-225-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-225-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-225-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-225-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-225-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-225-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-225-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-225-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** finite covariance, weak ID, nonlinear endpoints와 staged data를 동시에 다루는 calibrated inference layer를 완성한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-226 — Track-I data-lane closure and independent calibration

- **Track / dependencies / cost / risk:** `I` / PR-221, PR-222, PR-224, PR-225 / `high` / `medium`.
- **Hostile findings:** H2-19, H2-20, H2-21, H2-22.
- **강화 목표 claim:** Planck/CF4/DESI/ACT의 solver-independent results를 각각 complete null/covariance/selection contract로 닫는다.
- **Decisive falsifier:** partial mocks, unmatched masks, undercoverage 또는 unavailable raw stage가 headline inference에 들어가는 경우.
- **실제로 할 것:** data-lane manifests, independent nulls, exact/cluster-safe ranks, CF4 structural/robustness split과 official mock gates를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `context/external_audit_research_report_v10.pdf` — `read/reference context/external_audit_research_report_v10.pdf`
  - `references/WEB_SOURCES.md` — `read/reference references/WEB_SOURCES.md`
- **PASS gates:**
  - [ ] PR-226-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-226-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-226-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-226-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-226-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-226-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-226-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-226-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** Planck/CF4/DESI/ACT의 solver-independent results를 각각 complete null/covariance/selection contract로 닫는다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-227 — Independent reproduction, source audit and publication-grade capsule

- **Track / dependencies / cost / risk:** `I` / PR-209, PR-214, PR-226 / `medium` / `medium`.
- **Hostile findings:** H2-25, H2-26.
- **강화 목표 claim:** Track I 전체를 clean machine과 non-author analyst가 재현하고 source equation까지 audit하게 한다.
- **Decisive falsifier:** author cache 또는 untracked file 없이는 결과가 생성되지 않거나 independent analyst가 tolerance를 통과하지 못하는 경우.
- **실제로 할 것:** container lock, data recipes, source scans, signed external receipt와 reproduce-track-I target을 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/legacy_manifest_audit.py` — `python experiments/legacy_manifest_audit.py`
  - `docs/04_PUBLICATION_READINESS_MASTER_CHECKLIST_ROUND2.md` — `read/reference docs/04_PUBLICATION_READINESS_MASTER_CHECKLIST_ROUND2.md`
- **PASS gates:**
  - [ ] PR-227-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-227-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-227-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-227-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-227-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-227-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-227-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-227-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** Track I 전체를 clean machine과 non-author analyst가 재현하고 source equation까지 audit하게 한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-228 — Track-I adjudication checkpoint and v11-I comprehensive report

- **Track / dependencies / cost / risk:** `I` / PR-227 / `medium` / `high`.
- **Hostile findings:** H2-31.
- **강화 목표 claim:** solver 없이 가능한 programme를 하나의 완결된 internal research release로 닫고 publication candidates를 분리한다.
- **Decisive falsifier:** open P0가 result section에 남거나 Track II claim이 v11-I에 포함되는 경우.
- **실제로 할 것:** hostile rereview, claim delta, failures, reproducibility package와 Paper-A candidate를 생성한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `docs/03_ROUND2_DUAL_TRACK_PR_ROADMAP_20260721.md` — `read/reference docs/03_ROUND2_DUAL_TRACK_PR_ROADMAP_20260721.md`
  - `docs/04_PUBLICATION_READINESS_MASTER_CHECKLIST_ROUND2.md` — `read/reference docs/04_PUBLICATION_READINESS_MASTER_CHECKLIST_ROUND2.md`
- **PASS gates:**
  - [ ] PR-228-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-228-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-228-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-228-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-228-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
- **FAIL / kill gates:**
  - [ ] PR-228-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-228-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-228-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
- **최대 승격 claim:** solver 없이 가능한 programme를 하나의 완결된 internal research release로 닫고 publication candidates를 분리한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-229 — Native Bianchi Boltzmann solver delivery and authenticity gate

- **Track / dependencies / cost / risk:** `II` / PR-214, PR-218, PR-223 / `high` / `high`.
- **Hostile findings:** H2-27, H2-30.
- **강화 목표 claim:** 형식적 interface가 아니라 physics-complete native solver delivery를 content-addressed contract로 인증한다.
- **Decisive falsifier:** synthetic fixture나 wrapper가 native=true로 통과하거나 independent oracle 없이 Track II가 열린 경우.
- **실제로 할 것:** delivery schema, source/environment hash, build logs, independent oracle와 BLOCKED exit를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/solver_contract_validator.py` — `python experiments/solver_contract_validator.py`
  - `fixtures/solver_delivery_required_template.json` — `read/reference fixtures/solver_delivery_required_template.json`
  - `schemas/solver_delivery.schema.json` — `read/reference schemas/solver_delivery.schema.json`
- **PASS gates:**
  - [ ] PR-229-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-229-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-229-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-229-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-229-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-229-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-229-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-229-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-229-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-229-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** 형식적 interface가 아니라 physics-complete native solver delivery를 content-addressed contract로 인증한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-230 — FLRW null, Bianchi-I and analytic ray benchmark suite

- **Track / dependencies / cost / risk:** `II` / PR-229 / `high` / `high`.
- **Hostile findings:** H2-12, H2-27.
- **강화 목표 claim:** solver의 zero-anisotropy와 analytic anisotropic limits를 machine-precision benchmark로 확정한다.
- **Decisive falsifier:** FLRW에서 T/E/B anisotropic output이 tolerance를 넘거나 Bianchi-I analytic ray limit을 재현하지 못하는 경우.
- **실제로 할 것:** FLRW null, conserved momenta, Sachs-Wolfe shear integral, convergence order와 independent implementation을 구축한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `legacy_sources/curated_original/framework/bass/pstf_hierarchy.py` — `python legacy_sources/curated_original/framework/bass/pstf_hierarchy.py`
  - `fixtures/synthetic_solver_output.json` — `read/reference fixtures/synthetic_solver_output.json`
- **PASS gates:**
  - [ ] PR-230-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-230-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-230-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-230-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-230-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-230-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-230-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-230-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-230-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-230-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** solver의 zero-anisotropy와 analytic anisotropic limits를 machine-precision benchmark로 확정한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-231 — Exact Bianchi family background and constraint atlas

- **Track / dependencies / cost / risk:** `II` / PR-229, PR-230 / `high` / `high`.
- **Hostile findings:** H2-13, H2-27.
- **강화 목표 claim:** 11 Bianchi types의 background dynamics, Jacobi, constraints와 FLRW limits를 native solver state로 완성한다.
- **Decisive falsifier:** class A/B, Ricci scalar 또는 constraint propagation이 independent exact oracle와 불일치하는 경우.
- **실제로 할 것:** structure constants, tetrad connection, matter constraints와 background integrator를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/bianchi_classification_audit.py` — `python experiments/bianchi_classification_audit.py`
- **PASS gates:**
  - [ ] PR-231-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-231-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-231-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-231-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-231-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-231-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-231-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-231-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-231-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-231-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** 11 Bianchi types의 background dynamics, Jacobi, constraints와 FLRW limits를 native solver state로 완성한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-232 — Photon geodesic and temperature hierarchy

- **Track / dependencies / cost / risk:** `II` / PR-230, PR-231 / `high` / `high`.
- **Hostile findings:** H2-12, H2-27.
- **강화 목표 claim:** reduced transfer를 넘어 Bianchi temperature hierarchy와 line-of-sight transfer를 native하게 계산한다.
- **Decisive falsifier:** analytic small-shear response, energy conservation 또는 hierarchy convergence가 실패하는 경우.
- **실제로 할 것:** geodesic/redshift, Liouville hierarchy, lmax convergence와 reference transfer를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `legacy_sources/curated_original/framework/bass/pstf_hierarchy.py` — `python legacy_sources/curated_original/framework/bass/pstf_hierarchy.py`
- **PASS gates:**
  - [ ] PR-232-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-232-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-232-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-232-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-232-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-232-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-232-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-232-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-232-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-232-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** reduced transfer를 넘어 Bianchi temperature hierarchy와 line-of-sight transfer를 native하게 계산한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-233 — Thomson collision, recombination and reionization physics

- **Track / dependencies / cost / risk:** `II` / PR-232 / `high` / `high`.
- **Hostile findings:** H2-12, H2-27.
- **강화 목표 claim:** collisionless toy를 실제 CMB transfer solver로 업그레이드한다.
- **Decisive falsifier:** standard FLRW visibility/C_l limit이나 recombination/reionization toggles를 재현하지 못하는 경우.
- **실제로 할 것:** electron frame, collision operator, visibility, tight coupling와 reionization integration을 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `references/WEB_SOURCES.md` — `read/reference references/WEB_SOURCES.md`
- **PASS gates:**
  - [ ] PR-233-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-233-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-233-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-233-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-233-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-233-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-233-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-233-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-233-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-233-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** collisionless toy를 실제 CMB transfer solver로 업그레이드한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-234 — Temperature–polarization E/B hierarchy and parity oracle

- **Track / dependencies / cost / risk:** `II` / PR-233 / `high` / `high`.
- **Hostile findings:** H2-27.
- **강화 목표 claim:** Bianchi temperature뿐 아니라 E/B polarization와 handed morphology를 native하게 계산한다.
- **Decisive falsifier:** parity mirror, m=0 B-zero 또는 published near-FLRW polarization benchmark가 실패하는 경우.
- **실제로 할 것:** spin hierarchy, Thomson polarization source, parity/mirror mutations와 E/B spectra를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `references/WEB_SOURCES.md` — `read/reference references/WEB_SOURCES.md`
- **PASS gates:**
  - [ ] PR-234-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-234-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-234-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-234-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-234-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-234-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-234-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-234-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-234-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-234-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** Bianchi temperature뿐 아니라 E/B polarization와 handed morphology를 native하게 계산한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-235 — Tilted and multi-fluid species dynamics

- **Track / dependencies / cost / risk:** `II` / PR-231, PR-233, PR-223 / `high` / `high`.
- **Hostile findings:** H2-23, H2-27.
- **강화 목표 claim:** species-resolved tilt, heat flux, anisotropic stress와 collision coupling을 Einstein–Boltzmann evolution에 포함한다.
- **Decisive falsifier:** total stress-energy conservation, frame transforms 또는 known two-fluid limits가 실패하는 경우.
- **실제로 할 것:** species states, collisions, momentum constraints와 multi-fluid benchmarks를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `proofs/sympy/multi_fluid_moment_seal.py` — `python proofs/sympy/multi_fluid_moment_seal.py`
- **PASS gates:**
  - [ ] PR-235-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-235-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-235-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-235-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-235-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-235-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-235-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-235-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-235-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-235-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** species-resolved tilt, heat flux, anisotropic stress와 collision coupling을 Einstein–Boltzmann evolution에 포함한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-236 — Native observable response Jacobian and numerical error model

- **Track / dependencies / cost / risk:** `II` / PR-232, PR-234, PR-235 / `high` / `high`.
- **Hostile findings:** H2-14, H2-27.
- **강화 목표 claim:** hand-designed response를 native derivative map과 certified numerical error로 대체한다.
- **Decisive falsifier:** finite differences/autodiff/adjoint derivatives가 tolerance 밖이거나 error model이 coverage를 못하는 경우.
- **실제로 할 것:** observable Jacobian, parameter scaling, rank uncertainty와 derivative challenge suite를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/response_equivalence_quotient.py` — `python experiments/response_equivalence_quotient.py`
- **PASS gates:**
  - [ ] PR-236-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-236-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-236-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-236-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-236-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-236-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-236-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-236-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-236-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-236-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** hand-designed response를 native derivative map과 certified numerical error로 대체한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-237 — Native morphology atlas across Bianchi families

- **Track / dependencies / cost / risk:** `II` / PR-231, PR-234, PR-236 / `high` / `high`.
- **Hostile findings:** H2-13, H2-14.
- **강화 목표 claim:** temperature, E/B, BiPoSH, handedness와 orientation의 family morphology atlas를 구축한다.
- **Decisive falsifier:** mirror/parity/FLRW limits 또는 independent literature benchmark가 실패하는 경우.
- **실제로 할 것:** family grid, orientation quotient, morphology fingerprints와 interpolation error를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `legacy_sources/archives/bianchi_defect_overleaf_20260314.zip` — `read/reference legacy_sources/archives/bianchi_defect_overleaf_20260314.zip`
- **PASS gates:**
  - [ ] PR-237-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-237-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-237-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-237-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-237-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-237-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-237-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-237-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-237-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-237-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** temperature, E/B, BiPoSH, handedness와 orientation의 family morphology atlas를 구축한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-238 — Native response quotient and family-identifiability lattice

- **Track / dependencies / cost / risk:** `II` / PR-236, PR-237, PR-219 / `high` / `high`.
- **Hostile findings:** H2-14, H2-15.
- **강화 목표 claim:** observable set과 survey noise마다 어떤 Bianchi family quotient가 실제로 깨지는지 계산한다.
- **Decisive falsifier:** surrogate zero columns가 native rank를 대신하거나 rank confidence가 0을 포함하는데 family ID를 내는 경우.
- **실제로 할 것:** whitened native Jacobian, nuisance projection, rank intervals와 reopening lattice를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/response_equivalence_quotient.py` — `python experiments/response_equivalence_quotient.py`
- **PASS gates:**
  - [ ] PR-238-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-238-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-238-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-238-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-238-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-238-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-238-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-238-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-238-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-238-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** observable set과 survey noise마다 어떤 Bianchi family quotient가 실제로 깨지는지 계산한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-239 — Native calibration of Teff and legacy BASS surrogates

- **Track / dependencies / cost / risk:** `II` / PR-218, PR-236 / `high` / `high`.
- **Hostile findings:** H2-11, H2-12, H2-28.
- **강화 목표 claim:** 구 Teff의 유효 domain, failure modes와 certified emulator error를 native solver로 정량화한다.
- **Decisive falsifier:** holdout/challenge error가 envelope를 넘거나 same-run leakage가 발견되는 경우.
- **실제로 할 것:** nested design, active learning, adversarial extremes, release-hash-bound certificates를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/teff_surrogate_certification.py` — `python experiments/teff_surrogate_certification.py`
  - `legacy_sources/patched/bass/surrogate_contract.py` — `python legacy_sources/patched/bass/surrogate_contract.py`
- **PASS gates:**
  - [ ] PR-239-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-239-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-239-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-239-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-239-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-239-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-239-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-239-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-239-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-239-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** 구 Teff의 유효 domain, failure modes와 certified emulator error를 native solver로 정량화한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-240 — Common latent cosmology multi-probe forward model

- **Track / dependencies / cost / risk:** `II` / PR-222, PR-226, PR-235, PR-236 / `high` / `high`.
- **Hostile findings:** H2-18, H2-20, H2-29.
- **강화 목표 claim:** 동일한 frame/epoch/species/dynamics가 CMB, velocity, number counts와 lensing을 동시에 생성하는 full model을 구축한다.
- **Decisive falsifier:** probe마다 서로 다른 latent beta/curvature를 몰래 쓰거나 marginal branches의 Cartesian product만 계산하는 경우.
- **실제로 할 것:** joint latent state, survey windows, cross-covariance, selection/systematic sources와 full feasible set을 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/joint_identified_set.py` — `python experiments/joint_identified_set.py`
  - `experiments/bulk_to_tilt_bridge.py` — `python experiments/bulk_to_tilt_bridge.py`
- **PASS gates:**
  - [ ] PR-240-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-240-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-240-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-240-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-240-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-240-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-240-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-240-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-240-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-240-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** 동일한 frame/epoch/species/dynamics가 CMB, velocity, number counts와 lensing을 동시에 생성하는 full model을 구축한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-241 — Planck temperature/polarization native likelihood and null validation

- **Track / dependencies / cost / risk:** `II` / PR-234, PR-237, PR-238, PR-240 / `high` / `high`.
- **Hostile findings:** H2-21, H2-27, H2-29.
- **강화 목표 claim:** Planck morphology를 native Bianchi transfer와 matched simulations로 직접 검정한다.
- **Decisive falsifier:** component separation/null pipeline replication, likelihood coverage 또는 blind injections가 실패하는 경우.
- **실제로 할 것:** map likelihood or sufficient morphology likelihood, NPIPE/FFP replication, nuisance/foreground model와 blind recovery를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `references/WEB_SOURCES.md` — `read/reference references/WEB_SOURCES.md`
- **PASS gates:**
  - [ ] PR-241-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-241-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-241-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-241-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-241-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-241-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-241-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-241-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-241-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-241-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** Planck morphology를 native Bianchi transfer와 matched simulations로 직접 검정한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-242 — Track-II external solver adjudication and v11-II report

- **Track / dependencies / cost / risk:** `II` / PR-239, PR-241 / `high` / `high`.
- **Hostile findings:** H2-25, H2-27, H2-30.
- **강화 목표 claim:** native solver와 morphology programme를 외부 독립 검증 후 완결된 internal release로 닫는다.
- **Decisive falsifier:** same-team oracle만 통과하거나 Track I surrogate가 native claim의 evidence로 남는 경우.
- **실제로 할 것:** external code review, independent benchmark run, solver release archive와 Paper-B candidate를 생성한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `docs/08_TRACK_BOUNDARY_AND_SOLVER_HANDOFF_CONTRACT.md` — `read/reference docs/08_TRACK_BOUNDARY_AND_SOLVER_HANDOFF_CONTRACT.md`
- **PASS gates:**
  - [ ] PR-242-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-242-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-242-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-242-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-242-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-242-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-242-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-242-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-242-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-242-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** native solver와 morphology programme를 외부 독립 검증 후 완결된 internal release로 닫는다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-243 — Cross-track common-model comparator and source-discrimination synthesis

- **Track / dependencies / cost / risk:** `INTEGRATION` / PR-228, PR-242 / `high` / `high`.
- **Hostile findings:** H2-07, H2-17, H2-29.
- **강화 목표 claim:** Track I data/source model과 Track II native transfer를 결합해 실제 common-model xC identified/posterior region을 산출한다.
- **Decisive falsifier:** 공통 solution witness 없이 marginal intervals를 조립하거나 bridge uncertainty를 0으로 두는 경우.
- **실제로 할 것:** joint forward model, common feasible set, posterior/identified-set dual analysis와 source attribution을 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `experiments/joint_identified_set.py` — `python experiments/joint_identified_set.py`
  - `experiments/cosmic_dipole_source_discrimination.py` — `python experiments/cosmic_dipole_source_discrimination.py`
- **PASS gates:**
  - [ ] PR-243-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-243-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-243-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-243-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-243-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-243-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-243-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-243-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-243-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-243-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** Track I data/source model과 Track II native transfer를 결합해 실제 common-model xC identified/posterior region을 산출한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-244 — Hostile external replication and red-team challenge

- **Track / dependencies / cost / risk:** `INTEGRATION` / PR-243 / `high` / `high`.
- **Hostile findings:** H2-25, H2-26, H2-31.
- **강화 목표 claim:** programme의 가장 강한 full-scope claim을 독립 팀의 hostile challenge에서 살아남게 한다.
- **Decisive falsifier:** blind injections, mutation, source swaps 또는 alternate priors에서 preregistered gate가 하나라도 실패하는 경우.
- **실제로 할 것:** sealed challenge, independent analysis, dissent archive와 adjudication receipt를 구현한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `docs/01_HOSTILE_REFEREE_STEELMAN_ROUND2.md` — `read/reference docs/01_HOSTILE_REFEREE_STEELMAN_ROUND2.md`
  - `docs/02_ADVOCATE_STEELMAN_UPGRADE_ROUND2.md` — `read/reference docs/02_ADVOCATE_STEELMAN_UPGRADE_ROUND2.md`
- **PASS gates:**
  - [ ] PR-244-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-244-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-244-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-244-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-244-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-244-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-244-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-244-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-244-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-244-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** programme의 가장 강한 full-scope claim을 독립 팀의 hostile challenge에서 살아남게 한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-245 — Publication suite: methods/data, solver/theory, joint cosmology

- **Track / dependencies / cost / risk:** `INTEGRATION` / PR-244 / `high` / `high`.
- **Hostile findings:** H2-31.
- **강화 목표 claim:** programme 범위를 낮추지 않으면서 세 개의 독립적으로 완결된 논문으로 외부 공개한다.
- **Decisive falsifier:** 어느 논문도 독립 abstract, theorem/result, data/proof capsule와 falsifier를 갖지 못하는 경우.
- **실제로 할 것:** Paper A/B/C source, supplements, DOI archives, claim crosswalk와 common programme overview를 생성한다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `docs/04_PUBLICATION_READINESS_MASTER_CHECKLIST_ROUND2.md` — `read/reference docs/04_PUBLICATION_READINESS_MASTER_CHECKLIST_ROUND2.md`
- **PASS gates:**
  - [ ] PR-245-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-245-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-245-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-245-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-245-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-245-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-245-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-245-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-245-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-245-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** programme 범위를 낮추지 않으면서 세 개의 독립적으로 완결된 논문으로 외부 공개한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

### PR-246 — Final programme synthesis and long-horizon release

- **Track / dependencies / cost / risk:** `INTEGRATION` / PR-245 / `high` / `high`.
- **Hostile findings:** H2-01, H2-30, H2-31, H2-32.
- **강화 목표 claim:** 초기 post-FLRW 야심을 typed, native-transfer, multi-probe programme로 완전히 재성립한다.
- **Decisive falsifier:** legacy result가 근거 없이 resurrection되거나 Track boundary/publication receipts가 불완전한 경우.
- **실제로 할 것:** full historical provenance, current theory/data products, failures와 future native extensions를 하나의 self-contained release로 만든다.
- **하지 말 것:** scope 문구만 약화하거나 old number를 새 receipt에 복사하지 않는다. favorable outcome을 목적으로 domain/nuisance/threshold를 결과 후 변경하지 않는다.
- **제공 asset과 사용법:**
  - `legacy_sources/monograph/main_FINAL_20260314.pdf` — `read/reference legacy_sources/monograph/main_FINAL_20260314.pdf`
  - `docs/03_ROUND2_DUAL_TRACK_PR_ROADMAP_20260721.md` — `read/reference docs/03_ROUND2_DUAL_TRACK_PR_ROADMAP_20260721.md`
- **PASS gates:**
  - [ ] PR-246-P1: SPEC가 claim identity, estimand/domain, frame/order, input/output schema와 사전 falsifier를 결과 열람 전에 고정한다.
  - [ ] PR-246-P2: 최소 두 개의 독립 구현 또는 analytic oracle이 선언 tolerance 안에서 일치한다.
  - [ ] PR-246-P3: 해당 hostile mutation 전부가 nonzero exit 또는 BLOCKED status로 kill된다.
  - [ ] PR-246-P4: seeded repeated run과 clean temporary directory run이 byte-identical 또는 declared numeric tolerance 안에서 재현된다.
  - [ ] PR-246-P5: 모든 downstream consumer가 새 artifact hash를 참조하고 stale/legacy production path scan이 0 hit다.
  - [ ] PR-246-P6: real native `SolverDeliveryReceipt`가 schema와 physics benchmarks를 모두 통과한다; synthetic interface fixture는 절대 science PASS가 아니다.
- **FAIL / kill gates:**
  - [ ] PR-246-F1: decisive falsifier가 한 번이라도 살아남으면 scientific promotion을 금지하고 failure receipt를 남긴다.
  - [ ] PR-246-F2: 입력 provenance, frame, covariance/null 또는 independent adjudication이 누락되면 PASS를 반환하지 않는다.
  - [ ] PR-246-F3: claim 문구 축소만으로 결함을 닫거나 legacy 숫자를 새 결과로 복사하면 PR을 reject한다.
  - [ ] PR-246-F4: solver receipt가 없거나 native=false이면 exit 3 `BLOCKED_NATIVE_REQUIRED`로 종료한다.
- **최대 승격 claim:** 초기 post-FLRW 야심을 typed, native-transfer, multi-probe programme로 완전히 재성립한다. 단, 위 gate 전부와 독립 adjudication 이후에만 허용.

## 5. Checkpoints

- **Checkpoint I-A (PR-214):** legacy authority, convention, claim state와 mutation corpus.
- **Checkpoint I-B (PR-220):** pre-solver mathematical/evidence foundations.
- **Checkpoint I-C (PR-228):** Track-I full research report and external-ready methods/data candidates.
- **Checkpoint II-A (PR-234):** native temperature/polarization physics.
- **Checkpoint II-B (PR-242):** external solver adjudication.
- **Checkpoint Joint (PR-246):** common-model programme release.
