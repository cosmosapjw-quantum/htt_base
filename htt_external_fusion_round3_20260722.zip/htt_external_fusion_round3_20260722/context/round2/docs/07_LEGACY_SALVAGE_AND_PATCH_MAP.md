# Legacy Salvage and Patch Map

| Legacy object | Disposition | Successor |
|---|---|---|
| BASS–HTT–MIO split | KEEP_INTERFACE | `revival_core`, PR-210 |
| master defect identity | KEEP_MATH after convention repair | PR-211, T2-W2-SSOT |
| three-frame diagram | KEEP_VISUAL_LANGUAGE | PR-212 frame graph |
| MIO status schema | KEEP_INTERFACE | PR-213 dual-axis claim state |
| family equivalence audit | KEEP_MATH | PR-219 response quotient |
| MES shear/geodesic branch | REBUILD_PRE_SOLVER | PR-217 |
| old non-geodesic omega/acceleration coefficients | RETIRE_RESULT pending sources | PR-217 branch registry |
| Teff moment algebra | SOLVER_BENCHMARK | PR-218/239 certified surrogate |
| reduced PSTF hierarchy | SOLVER_BENCHMARK | PR-230/232 regression suite |
| old evidence model | MUTATION_FIXTURE | PR-220/221 |
| old Bianchi atlas | MUTATION_FIXTURE + REBUILD | PR-231/237 |
| CF4 beta substitution | RETIRE_RESULT | PR-222 stochastic bridge |
| Tsagas H0 percentage tables | HYPOTHESIS_ONLY | PR-224 falsifier programme |
| multi-fluid section | REBUILD_PRE_SOLVER | PR-223/235 |

원본과 수정본은 동시에 포함되지만, production import는 `legacy_sources/patched` 또는 `revival_core`에서만 시작한다.
