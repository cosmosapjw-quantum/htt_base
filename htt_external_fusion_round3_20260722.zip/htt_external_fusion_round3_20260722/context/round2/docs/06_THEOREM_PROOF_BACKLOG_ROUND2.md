# Round-2 Theorem and Proof Backlog

## T2-W2-SSOT — Constraint-normalized vorticity convention uniqueness

- **Track:** `I`
- **Proof route:** derive dual identity and every conversion; mutation factor-three must fail
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-DEFECT-BUNDLE — Frame-indexed comparator functor

- **Track:** `I`
- **Proof route:** prove same-frame linear projection and obstruction to unbridged frame mixing
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-CURVATURE-SPLIT — Scalar curvature departure versus PSTF curvature sector

- **Track:** `I`
- **Proof route:** derive independent tensor/scalar carriers and response maps
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-EGS-LATTICE — Premise lattice for exact/almost EGS

- **Track:** `I`
- **Proof route:** classify acceleration and derivative-premise counterexamples
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-JOINT-SUPPORT — Support image on common feasible set

- **Track:** `I`
- **Proof route:** general compact-set theorem; box is a corollary
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-PHYSICAL-SHARPNESS — Constraint/local/global endpoint attainability

- **Track:** `I→II`
- **Proof route:** construct initial data, local development and global branch certificates
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-MES-BRANCH — Source-exact MES branch hierarchy

- **Track:** `I`
- **Proof route:** derive geodesic/non-geodesic/acceleration branches independently
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-INACTIVE-EVIDENCE — Inactive normalized prior invariance

- **Track:** `I`
- **Proof route:** measure-theoretic and numerical proof
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-RESPONSE-QUOTIENT — Observable response equivalence quotient

- **Track:** `I→II`
- **Proof route:** prove refinement under row augmentation and rank uncertainty
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-BULK-BRIDGE — Finite-window bulk-to-homogeneous-mode identification

- **Track:** `I`
- **Proof route:** operator rank and stochastic covariance theorem
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-MULTIFLUID — Multi-fluid first/second-moment non-equivalence

- **Track:** `I`
- **Proof route:** zero flux does not imply zero tilt energy/stress
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-CLUSTER-RANK — Cluster-exchangeable finite rank

- **Track:** `I`
- **Proof route:** derive valid randomized/cluster calibration
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-ESTCOV-PID — Estimated-covariance partial-ID confidence

- **Track:** `I`
- **Proof route:** finite/asymptotic coverage with active boundaries
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-EVALUE — Dependent finite-cover and sequential e-values

- **Track:** `I`
- **Proof route:** predictable weighting and optional stopping
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-SOLVER-NULL — Native FLRW null and analytic Bianchi-I transfer

- **Track:** `II`
- **Proof route:** temperature/polarization benchmarks
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-POLARIZATION — Bianchi E/B parity and handedness

- **Track:** `II`
- **Proof route:** representation and solver equivalence
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-NATIVE-RANK — Native transfer Jacobian identifiability

- **Track:** `II`
- **Proof route:** rank confidence and quotient refinement
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-SURROGATE — Certified Teff/native remainder

- **Track:** `II`
- **Proof route:** held-out uniform error envelope
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.

## T2-COMMON-MODEL — Common latent cosmology joint identified region

- **Track:** `II/Joint`
- **Proof route:** one state generates all probes and constraints
- **Promotion:** statement, assumptions, counterexample registry, at least two independent lineages and downstream consumer tests are all required.
