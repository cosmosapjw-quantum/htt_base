#!/usr/bin/env python3
from __future__ import annotations
import importlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments'))
OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True)
MODULES=['legacy_manifest_audit','defect_bundle_typecheck','inactive_parameter_evidence_invariance','response_equivalence_quotient','joint_identified_set','finite_covariance_partial_id','evalue_anytime','mes_attribution_surface','teff_surrogate_certification','multi_fluid_flux_cancellation','bulk_to_tilt_bridge','cosmic_dipole_source_discrimination','directional_depth_falsifier','legacy_mutation_suite','bianchi_classification_audit','track_boundary_validator']
PROOFS=['defect_identity_seal.py','inactive_prior_invariance.py','multi_fluid_moment_seal.py','bulk_bridge_rank.py','w2_normalization_seal.py']
summary={'track_I':{},'proofs':{},'track_II_native_gate':{}}
ok=True
for name in MODULES:
    try:
        mod=importlib.import_module(name);data=mod.run();code=0 if data.get('status')=='PASS' else 2
    except Exception as exc:
        data={'status':'FAIL','exception':repr(exc)};code=2
    (OUT/(name+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True,ensure_ascii=False,default=lambda x:x.item() if hasattr(x,'item') else str(x))+'\n')
    summary['track_I'][name+'.py']={'exit':code,'status':data.get('status')};ok &= code==0 and data.get('status')=='PASS'
for s in PROOFS:
    try:
        p=subprocess.run([sys.executable,str(ROOT/'proofs/sympy'/s)],capture_output=True,text=True,timeout=30)
        data=json.loads(p.stdout);code=p.returncode
    except Exception as exc:
        data={'status':'FAIL','exception':repr(exc)};code=2
    (OUT/('proof_'+Path(s).stem+'.json')).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    summary['proofs'][s]={'exit':code,'status':data.get('status')};ok &= code==0 and data.get('status')=='PASS'
from solver_contract_validator import run as solver_run
data=solver_run(ROOT/'fixtures/solver_delivery_synthetic_interface.json',True)
(OUT/'solver_contract_native_required.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
expected=data.get('status')=='EXPECTED_BLOCK'
summary['track_II_native_gate']={'exit':3 if expected else 2,'status':data.get('status'),'expected_block':expected};ok &= expected
summary['status']='PASS' if ok else 'FAIL'
(OUT/'run_all_summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2,sort_keys=True));raise SystemExit(0 if ok else 2)
