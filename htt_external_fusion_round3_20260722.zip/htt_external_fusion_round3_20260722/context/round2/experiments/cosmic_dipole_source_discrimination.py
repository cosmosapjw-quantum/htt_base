#!/usr/bin/env python3
"""Synthetic multi-survey source discrimination with mandatory inadequacy abstention."""
from __future__ import annotations
import argparse,numpy as np
from scipy.stats import chi2
from common import dump

def run(seed=20260721,nrep=4000,nobs=24):
    rng=np.random.default_rng(seed);x=np.linspace(0,1,nobs)
    kin=.5+1.5*(.2+np.sin(2*np.pi*x)**2);glob=np.ones(nobs);sys=np.sin(4*np.pi*x)+.3*np.cos(2*np.pi*x);sys/=np.std(sys)
    amb=np.sign(np.sin(7*np.pi*x))+.4*np.cos(11*np.pi*x);amb/=np.std(amb)
    C=np.diag(np.full(nobs,.25**2))+.002*np.ones((nobs,nobs));Ci=np.linalg.inv(C);base=np.column_stack([kin,glob,sys])
    models={'kin':kin[:,None],'kin+global':np.column_stack([kin,glob]),'kin+sys':np.column_stack([kin,sys]),'full':base}
    means={'kin':base@np.array([1,0,0]),'global':base@np.array([1,.9,0]),'systematic':base@np.array([1,0,.9]),'superposition':base@np.array([1,.7,.7]),'confusable_weak':kin+.5*amb}
    truth={'kin':'kin','global':'kin+global','systematic':'kin+sys','superposition':'full','confusable_weak':'abstain'}
    per=max(1,nrep//len(means));results={};tot=0
    for name,mu in means.items():
        correct=abst=0
        for _ in range(per):
            y=mu+rng.multivariate_normal(np.zeros(nobs),C);scores=[];fits={}
            for m,X in models.items():
                F=X.T@Ci@X;b=X.T@Ci@y;beta=np.linalg.solve(F,b);r=y-X@beta;ch=float(r@Ci@r);fits[m]=(ch,nobs-X.shape[1]);scores.append((ch+X.shape[1]*np.log(nobs),m))
            scores.sort();best=scores[0][1];gap=scores[1][0]-scores[0][0];ch,dof=fits[best];adequate=(1-chi2.cdf(ch,dof))>.01
            if not adequate: chosen='abstain'
            elif best=='kin': chosen='kin'
            elif gap>1.0: chosen=best
            else: chosen='abstain'
            correct+=chosen==truth[name];abst+=chosen=='abstain'
        results[name]={'correct_rate':correct/per,'abstain_rate':abst/per};tot+=correct
    rate=tot/(per*len(means));ok=rate>.84 and results['superposition']['correct_rate']>.94 and results['confusable_weak']['abstain_rate']>.95
    return {'status':'PASS' if ok else 'FAIL','overall_correct_rate':rate,'scenario_results':results,'interpretation':'explicit kinematic, global, systematic and superposition competitors plus model-adequacy abstention are required'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
