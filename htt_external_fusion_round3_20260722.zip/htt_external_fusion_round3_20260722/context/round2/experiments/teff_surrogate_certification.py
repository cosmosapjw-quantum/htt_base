#!/usr/bin/env python3
from __future__ import annotations
import argparse,numpy as np
from common import dump

def surrogate(x):
    a,q,w=x.T;return np.column_stack([a+2*q-.3*w, q*q+.5*a*w, a*q-w*w])
def native(x):
    a,q,w=x.T;return surrogate(x)+np.column_stack([.20*a*q*w, -.15*a**3+.05*q*w*w, .10*q**3-.05*a*a*w])
def run(seed=20260721,ntrain=4000,ntest=3000):
    rng=np.random.default_rng(seed);scale=np.array([.02,.02,.01]);tr=rng.uniform(-scale,scale,(ntrain,3));te=rng.uniform(-scale,scale,(ntest,3))
    err=np.linalg.norm(native(tr)-surrogate(tr),axis=1);env=float(np.quantile(err,.999)*1.2+1e-12)
    e2=np.linalg.norm(native(te)-surrogate(te),axis=1);viol=int(np.sum(e2>env))
    out=np.array([[.08,.08,.04]]);oe=float(np.linalg.norm(native(out)-surrogate(out)))
    ok=viol==0 and oe>5*env
    return {'status':'PASS' if ok else 'FAIL','domain':{'abs_max':scale.tolist()},'certified_envelope':env,'test_max_error':float(e2.max()),'violations':viol,'out_of_domain_error':oe,'out_of_domain_rejected':oe>5*env}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
