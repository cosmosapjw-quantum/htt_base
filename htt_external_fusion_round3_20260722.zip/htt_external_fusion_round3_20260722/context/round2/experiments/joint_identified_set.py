#!/usr/bin/env python3
from __future__ import annotations
import argparse,numpy as np
from common import dump

def run(n=501):
    s=np.linspace(0,1,n);t=np.linspace(-1,1,n)
    # coupled feasible manifold: Sigma=.10+.02t; W=.03+.015t; tilt=.02+.01s; dk=-.01+.01s-.005t
    T,S=np.meshgrid(t,s,indexing='ij')
    x=(.10+.02*T)-(.03+.015*T)+(.02+.01*S)+(-.01+.01*S-.005*T)
    joint=(float(x.min()),float(x.max()))
    marg={'Sigma2':(.08,.12),'W2':(.015,.045),'Omega_tilt':(.02,.03),'DeltaOmega_k':(-.025,.005)}
    box=(marg['Sigma2'][0]-marg['W2'][1]+marg['Omega_tilt'][0]+marg['DeltaOmega_k'][0],marg['Sigma2'][1]-marg['W2'][0]+marg['Omega_tilt'][1]+marg['DeltaOmega_k'][1])
    ok=joint[0]>=box[0]-1e-12 and joint[1]<=box[1]+1e-12 and (joint[1]-joint[0])<(box[1]-box[0])
    return {'status':'PASS' if ok else 'FAIL','joint_interval':joint,'marginal_product_box_interval':box,'width_ratio':(joint[1]-joint[0])/(box[1]-box[0]),'interpretation':'the full comparator must be optimized on a common feasible model, not assembled from unrelated marginal branches'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
