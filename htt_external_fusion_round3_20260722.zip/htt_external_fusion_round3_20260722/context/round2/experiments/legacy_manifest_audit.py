#!/usr/bin/env python3
from __future__ import annotations
import argparse,zipfile
from pathlib import Path
from common import dump,sha256
ROOT=Path(__file__).resolve().parents[1]
def run():
    files=[]
    for p in sorted((ROOT/'legacy_sources').rglob('*')):
        if p.is_file(): files.append({'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha256(p)})
    archives=[]
    for p in sorted((ROOT/'legacy_sources/archives').glob('*.zip')):
        with zipfile.ZipFile(p) as z: archives.append({'path':p.relative_to(ROOT).as_posix(),'members':len([n for n in z.namelist() if not n.endswith('/')]),'bad_crc':z.testzip()})
    ok=all(a['bad_crc'] is None for a in archives) and len(files)>10
    return {'status':'PASS' if ok else 'FAIL','file_count':len(files),'archives':archives,'files':files}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
