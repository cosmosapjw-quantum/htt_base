#!/usr/bin/env python3
from __future__ import annotations
import argparse,numpy as np
from common import dump

def run(seed=20260721,n=50000,K=6,T=80,lam=.25):
    rng=np.random.default_rng(seed);z=rng.normal(size=(n,1));idio=rng.normal(size=(n,K));x=.9*z+np.sqrt(1-.9**2)*idio
    E=np.exp(lam*x-.5*lam**2);merged=E.mean(axis=1);tails={str(t):float(np.mean(merged>=t)) for t in [2,5,10]}
    inc=np.exp(lam*rng.normal(size=(n,T))-.5*lam**2);M=np.cumprod(inc,axis=1);cross=float(np.mean(M.max(axis=1)>=20))
    ok=abs(merged.mean()-1)<.015 and all(tails[str(t)]<=1/t+.005 for t in [2,5,10]) and cross<=.055
    return {'status':'PASS' if ok else 'FAIL','merged_mean':float(merged.mean()),'tail_probs':tails,'markov_bounds':{str(t):1/t for t in [2,5,10]},'ville_crossing_at_20':cross,'ville_bound':.05}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
