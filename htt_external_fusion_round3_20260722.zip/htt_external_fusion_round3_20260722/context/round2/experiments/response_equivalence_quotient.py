#!/usr/bin/env python3
from __future__ import annotations
import argparse,numpy as np
from common import dump

def quotient(labels,rows):
    unused=list(range(len(labels)));out=[]
    while unused:
        i=unused.pop(0);g=[labels[i]];keep=[]
        for j in unused:
            if np.allclose(rows[i],rows[j],atol=1e-12,rtol=0):g.append(labels[j])
            else:keep.append(j)
        unused=keep;out.append(g)
    return out

def run():
    labels=['BI','BV','BVIIh','FLRW_tilt']
    scalar=np.array([[1,0,1,0],[1,0,1,0],[1,0,1,0],[0,0,1,0]],float)
    enlarged=np.array([[1,0,1,0],[1,0,1,1],[1,1,1,1],[0,0,1,0]],float)
    ranks=[np.linalg.matrix_rank(scalar),np.linalg.matrix_rank(np.vstack([scalar,[0,1,0,0]])),np.linalg.matrix_rank(enlarged)]
    ok=quotient(labels,scalar)==[['BI','BV','BVIIh'],['FLRW_tilt']] and len(quotient(labels,enlarged))==4 and ranks[-1]==4
    return {'status':'PASS' if ok else 'FAIL','scalar_response_quotient':quotient(labels,scalar),'enlarged_response_quotient':quotient(labels,enlarged),'rank_lattice_scalar_transverse_curvature':ranks,'interpretation':'family labels are quotient classes of a declared observable response'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
