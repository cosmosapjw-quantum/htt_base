#!/usr/bin/env python3
from __future__ import annotations
import argparse,numpy as np
from common import dump

def run(seed=20260721,n=30):
    rng=np.random.default_rng(seed);d=np.linspace(30,600,max(n,40));kin=(1/d)/(1/30);global_mode=np.ones(len(d));age=np.exp(-d/170)
    X=np.column_stack([kin,global_mode,age]);truth=np.array([.8,.3,-.6]);y=X@truth+rng.normal(0,.015,len(d));b=np.linalg.lstsq(X,y,rcond=None)[0]
    wrong=np.linalg.lstsq(np.column_stack([global_mode,age]),y,rcond=None)[0];rss_full=np.sum((y-X@b)**2);rss_wrong=np.sum((y-np.column_stack([global_mode,age])@wrong)**2)
    ok=np.linalg.norm(b-truth)<.05 and rss_wrong>20*rss_full
    return {'status':'PASS' if ok else 'FAIL','truth':truth.tolist(),'fit':b.tolist(),'rss_full':float(rss_full),'rss_without_depth_inverse_mode':float(rss_wrong),'interpretation':'direction x depth x host-property structure can falsify a simple tilted-observer bridge without claiming it in advance'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
