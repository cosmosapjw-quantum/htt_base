#!/usr/bin/env python3
from __future__ import annotations
import argparse,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'revival_core'))
from revival_core.types import *
from revival_core.comparator import comparator_value,require_common_frame
from common import dump

def run():
    e=Epoch(redshift=0.0);g=ComponentState(.02,.005,.01,-.003,Frame.NORMAL,e);g.validate();x=comparator_value(g)
    mixed=False
    try: require_common_frame(g,ComponentState(.01,0,.001,0,Frame.MATTER,e))
    except ValueError: mixed=True
    missing=False
    try: ComponentState(-1,0,0,0,Frame.NORMAL,e).validate()
    except ValueError: missing=True
    ok=abs(x-.022)<1e-15 and mixed and missing
    return {'status':'PASS' if ok else 'FAIL','xC':x,'frame_mix_rejected':mixed,'negative_magnitude_rejected':missing}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
