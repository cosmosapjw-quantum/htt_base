#!/usr/bin/env python3
from __future__ import annotations
import argparse,numpy as np
from scipy.stats import chi2
from common import dump

def run(seed=20260721,nrep=3000,m=12,nsim=90):
    rng=np.random.default_rng(seed);alpha=(nsim-m-2)/(nsim-1);raw=[];cor=[]
    cover_known=cover_est=0
    for _ in range(nrep):
        sims=rng.normal(size=(nsim,m));S=np.cov(sims,rowvar=False);P=np.linalg.inv(S);y=rng.normal(size=m)
        raw.append(y@P@y);cor.append(alpha*y@P@y)
        # simple point-to-interval common-shift endpoint model
        eps=rng.normal();lo,hi=eps-.4,eps+.4
        c=1.96;cover_known += (lo-c<=0<=hi+c)
        infl=np.sqrt(np.mean(np.diag(S)));cover_est += (lo-c*infl<=0<=hi+c*infl)
    raw=np.asarray(raw);cor=np.asarray(cor)
    ok=raw.mean()/m>1.08 and abs(cor.mean()/m-1)<.04 and cover_known/nrep>.94 and cover_est/nrep>.92
    return {'status':'PASS' if ok else 'FAIL','m':m,'Nsim':nsim,'hartlap_factor':alpha,'raw_mean_over_m':float(raw.mean()/m),'corrected_mean_over_m':float(cor.mean()/m),'known_cov_coverage':cover_known/nrep,'estimated_cov_toy_coverage':cover_est/nrep,'note':'reference stress test; publication gates require DGP-grid and exact confidence bounds'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
