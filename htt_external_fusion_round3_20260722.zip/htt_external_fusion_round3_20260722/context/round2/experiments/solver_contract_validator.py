#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from common import dump
ROOT=Path(__file__).resolve().parents[1]
def validate(card,require_native=False):
    req=['schema_version','release_hash','source_commit','environment_hash','native','benchmarks','error_model'];missing=[k for k in req if k not in card]
    interface_ok=not missing and all(k in card.get('benchmarks',{}) for k in ['flrw_null','bianchi_i_temperature','polarization','independent_oracle'])
    science_ok=interface_ok and card['native'] and all(card['benchmarks'].values()) and card['error_model'].get('validated') is True
    return interface_ok,science_ok,missing
def run(path,require_native=False):
    card=json.loads(Path(path).read_text());i,s,m=validate(card,require_native);status='PASS' if (s if require_native else i) else ('EXPECTED_BLOCK' if require_native and i else 'FAIL')
    
    pp=Path(path)
    try: card_label=pp.resolve().relative_to(ROOT.resolve()).as_posix()
    except Exception: card_label=pp.name
    return {'status':status,'interface_ok':i,'scientific_track_ii_ready':s,'missing':m,'card':card_label}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('card',nargs='?',default=str(ROOT/'fixtures/solver_delivery_synthetic_interface.json'));ap.add_argument('--require-native',action='store_true');ap.add_argument('--out');a=ap.parse_args();r=run(a.card,a.require_native);dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else (3 if r['status']=='EXPECTED_BLOCK' else 2))
if __name__=='__main__':main()
