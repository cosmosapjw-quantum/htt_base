#!/usr/bin/env python3
from __future__ import annotations
import argparse,re,subprocess,tempfile
from pathlib import Path
from common import dump
ROOT=Path(__file__).resolve().parents[1]
PATTERNS={
 'old_large_bayes_factor':r'26\.4|10\^?\{?11',
 'old_bianchi_v_exclusion':r'Bianchi V.*exclud|quadrupole overproduction',
 'old_universal_teff':r'1\.478|0\.742|universal ratios',
 'old_bulk_equals_tilt':r'CF4.*tilt|directly comparable to the CF4 bulk',
 'old_h0_percentage':r'48%|Hubble correction',
}
def pdf_text(path):
    try:
        p=subprocess.run(['pdftotext',str(path),'-'],capture_output=True,text=True,timeout=60);return p.stdout
    except Exception:return ''
def run():
    texts=[]
    for p in (ROOT/'legacy_sources/curated_original').rglob('*'):
        if p.is_file() and p.suffix.lower() in {'.py','.md','.tex','.json'}:
            texts.append(p.read_text(errors='ignore'))
    texts.append(pdf_text(ROOT/'legacy_sources/monograph/main_FINAL_20260314.pdf'))
    texts.append(pdf_text(ROOT/'context/external_audit_research_report_v10.pdf'))
    corpus='\n'.join(texts);hits={k:len(re.findall(p,corpus,re.I|re.S)) for k,p in PATTERNS.items()};ok=all(v>0 for v in hits.values())
    return {'status':'PASS' if ok else 'FAIL','known_bad_mutation_hits':hits,'interpretation':'historical bad claims are preserved as executable negative controls, never imported as production conclusions'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
