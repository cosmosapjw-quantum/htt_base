#!/usr/bin/env python3
from __future__ import annotations
import argparse,math
import numpy as np
from common import dump

def log_evidence_grid(y,sigma,tau,n=20001):
    mu=np.linspace(-6*tau,6*tau,n);d=mu[1]-mu[0]
    logl=-.5*np.sum((y[:,None]-mu[None,:])**2/sigma**2,axis=0)-len(y)*math.log(math.sqrt(2*math.pi)*sigma)
    logp=-.5*(mu/tau)**2-math.log(math.sqrt(2*math.pi)*tau)
    m=np.max(logl+logp);return math.log(np.sum(np.exp(logl+logp-m))*d)+m

def run(seed=20260721):
    rng=np.random.default_rng(seed);y=rng.normal(.4,.7,12);base=log_evidence_grid(y,.7,1.5)
    # normalized inactive prior integrates to one; quadrature check
    phi=np.linspace(-5,5,20001);d=phi[1]-phi[0];p=np.exp(-phi**2/2)/math.sqrt(2*math.pi);mass=np.sum(p)*d
    augmented=base+math.log(mass);gap=augmented-base
    bad=base+math.log(10.0) # unnormalized prior mutation
    ok=abs(gap)<2e-6 and abs(bad-base)>2
    return {'status':'PASS' if ok else 'FAIL','logZ_base':base,'logZ_inactive_normalized':augmented,'gap':gap,'unnormalized_mutation_gap':bad-base,'interpretation':'inactive normalized parameters cannot create an Occam penalty'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
