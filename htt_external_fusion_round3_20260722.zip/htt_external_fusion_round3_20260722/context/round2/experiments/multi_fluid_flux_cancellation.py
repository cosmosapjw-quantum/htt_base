#!/usr/bin/env python3
from __future__ import annotations
import argparse,numpy as np
from common import dump

def run():
    v=np.array([.01,0,0]);streams=[(.5,v),(.5,-v)];first=sum(w*x for w,x in streams);K=sum(w*np.outer(x,x) for w,x in streams)
    tr=np.trace(K);Pi=K-tr/3*np.eye(3);Kiso=tr/3*np.eye(3)
    ok=np.linalg.norm(first)<1e-15 and tr>0 and np.linalg.norm(Pi)>0 and abs(np.trace(Kiso)-tr)<1e-15
    return {'status':'PASS' if ok else 'FAIL','net_flux_norm':float(np.linalg.norm(first)),'second_moment_trace':float(tr),'tracefree_difference_norm':float(np.linalg.norm(Pi)),'same_trace_isotropic_comparator':bool(abs(np.trace(Kiso)-tr)<1e-15),'interpretation':'zero first moment does not imply zero tilt energy or anisotropic stress'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
