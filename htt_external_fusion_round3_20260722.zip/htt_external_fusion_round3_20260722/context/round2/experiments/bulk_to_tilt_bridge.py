#!/usr/bin/env python3
from __future__ import annotations
import argparse,numpy as np
from common import dump

def run(seed=20260721,nrep=5000):
    rng=np.random.default_rng(seed);W=np.array([[1,.1,0],[.2,.8,.1],[0,.2,.7],[.6,.3,.2]])
    C=.3*np.eye(4)+.08*np.ones((4,4));Ci=np.linalg.inv(C);F=W.T@Ci@W;rank=int(np.linalg.matrix_rank(F))
    truth=np.array([.8,-.3,.2]);est=[]
    A=np.linalg.inv(F)@W.T@Ci
    for _ in range(nrep): est.append(A@(W@truth+rng.multivariate_normal(np.zeros(4),C)))
    est=np.array(est);bias=np.linalg.norm(est.mean(0)-truth)
    single_rank=int(np.linalg.matrix_rank(W[:1]))
    ok=rank==3 and single_rank==1 and bias<.03
    return {'status':'PASS' if ok else 'FAIL','multi_window_rank':rank,'single_window_rank':single_rank,'truth':truth.tolist(),'estimated_mean':est.mean(0).tolist(),'bias_norm':float(bias),'interpretation':'homogeneous tilt is identifiable only through a declared multi-window field bridge, not from one bulk-flow amplitude'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
