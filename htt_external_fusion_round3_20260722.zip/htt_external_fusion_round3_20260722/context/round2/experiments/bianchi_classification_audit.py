#!/usr/bin/env python3
from __future__ import annotations
import argparse
from common import dump
EXPECTED={'I':'A','II':'A','VI0':'A','VII0':'A','VIII':'A','IX':'A','III':'B','IV':'B','V':'B','VIh':'B','VIIh':'B'}
LEGACY_MUTATED={'I':'A','II':'A','VI0':'B','VII0':'A','VIII':'A','IX':'A','III':'B','IV':'B','V':'B','VIh':'B','VIIh':'A'}
def run():
    bad={k:(LEGACY_MUTATED[k],v) for k,v in EXPECTED.items() if LEGACY_MUTATED[k]!=v};ok=set(bad)=={'VI0','VIIh'}
    return {'status':'PASS' if ok else 'FAIL','expected':EXPECTED,'legacy_mutations_detected':bad,'interpretation':'legacy family tables are mutation fixtures; a new exact structure-constant atlas must be generated independently'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
