#!/usr/bin/env python3
from __future__ import annotations
import argparse,numpy as np
from common import dump

def run():
    e2=3.56e-6;e3=2.1e-6;e1=np.linspace(0,1.3e-3,401)
    Bs=5/3*e1+3*e2+3/7*e3;Bo=10/3*e1+2/15*e2
    crit=(43/25)*e2+(9/35)*e3
    admiss=e1<crit;W=1.5*Bo**2
    ok=admiss[0] and not admiss[-1] and W[-1]/max(W[0],1e-30)>1e6
    return {'status':'PASS' if ok else 'FAIL','epsilon1_crit':crit,'W2_at_intrinsic_zero':float(W[0]),'W2_at_full_observed_dipole':float(W[-1]),'hierarchy_holds_at_zero':bool(Bs[0]>Bo[0]),'hierarchy_holds_at_full':bool(Bs[-1]>Bo[-1]),'interpretation':'MES ceilings form an attribution surface; epsilon1=0 is a physical branch choice, not a theorem of algebra alone'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
