#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from common import dump
ROOT=Path(__file__).resolve().parents[1]
def run():
    dag=json.loads((ROOT/'docs/12_TRACK_DAG.json').read_text());nodes={x['id']:x for x in dag['prs']};viol=[]
    for p in dag['prs']:
        if p['track']=='I':
            for d in p['depends']:
                if d in nodes and nodes[d]['track']=='II':viol.append({'pr':p['id'],'illegal_dependency':d})
        if p['track']=='II' and not p.get('solver_gate_required',False):viol.append({'pr':p['id'],'missing_solver_gate':True})
    ok=not viol and len([p for p in dag['prs'] if p['track']=='I'])==20 and len([p for p in dag['prs'] if p['track']=='II'])==14
    return {'status':'PASS' if ok else 'FAIL','violations':viol,'track_I_count':sum(p['track']=='I' for p in dag['prs']),'track_II_count':sum(p['track']=='II' for p in dag['prs']),'integration_count':sum(p['track']=='INTEGRATION' for p in dag['prs'])}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out');a=ap.parse_args();r=run();dump(r,a.out);raise SystemExit(0 if r['status']=='PASS' else 2)
if __name__=='__main__':main()
