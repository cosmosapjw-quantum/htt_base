# HTT/BASS Departure-Decomposition — External Review Package

Critical & constructive research review of the BASS/HTT program (the
`htt_base_research_evaluation_package`), following the review prompt's required
eight sections, plus a voluntary additional audit and runnable independent
re-checks.

## Contents

| File | What it is |
|---|---|
| `RESEARCH_EVALUATION_REVIEW.md` | the main review (8 required sections: verdict, minimal defensible claim, novelty, fatal blockers, theorem audit, statistics audit, constructive roadmap, claim-tier corrections + safe claims) |
| `VOLUNTARY_ADDITIONAL_AUDIT.md` | items checked beyond the prompt (ledger consistency, rank-2 full-vs-partial, e-value null scope, K1 component-sep dependence, self-flagged contract failures, K6 injection scope, provenance) |
| `reviewer_verification.py` | stdlib-only independent re-checks (no project code imported): bracket constant, e-value Markov bound, Fisher-floor descent, radial-vorticity identity, and a demonstration of the Omega_k null-vs-degeneracy point |

## Verdict

**MINOR REVISIONS** — a genuinely publishable methods/identifiability/bounds
program. One substantive revision (make the `Omega_k` half of the two-sector
no-go precise: it is a leading-EGS-order no-channel, not the same kind of
structural null as `W^2`, and degeneracy-with-`Sigma^2` must be excluded), one
real gating measurement (the K1 FFP10/NPIPE E2E null), and a handful of
calibration caveats. The honesty discipline (fail-closed blind sectors,
ΛCDM-null labelling, structural-no-go framing, the corrected NT-A3) is exemplary.

## Run the independent checks

```bash
python3 reviewer_verification.py      # 5/5 checks confirmed (stdlib, Py3.10+)
```
