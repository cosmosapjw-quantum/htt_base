;+
; NAME:
;     get_rot_matrix
;
; PURPOSE:
;     Function to return the appropriate rotation matrix that will convert
;     between eclipctic, celestial and galactic coordinates in J2000.
;     
; CALLING SEQUENCE:
;     matrix = get_rot_matrix(rot_code)
;
; INPUTS:
;     code - char string - Character string specifying the desired
;                         coordinate conversion.  Only ONE code
;                         may be requested at a time.  Valid codes are:
;                         'c2e' - from = celestial   to = ecliptic
;                         'e2c' - from = ecliptic    to = celestial
;                         'g2e' - from = galactic    to = ecliptic
;                         'e2g' - from = ecliptic    to = galactic
;                         'c2g' - from = celestial   to = galactic
;                         'g2c' - from = galactic    to = celestial
;
;
; OUTPUTS:  
;     matrix - dblarr -   The 3x3 rotation matrix appropriate to
;                         the specified code.  The rotation matrix operates
;                         on a unit vector with 3 ROWS: x,y,z.
;
; KEYWORDS:
;     None.
;
; ROUTINES CALLED:
;     rotx, roty, rotz
;
; EXAMPLE:
;     Convert a single unit vector in celestial to galactic.  IDL's
;     (column x row) convention makes this a little tricky:
;       cel_uvec   = [1,0,0]
;       rot_matrix = get_rot_matrix('c2g')
;       gal_uvec   = transpose(rot_matrix) # cel_uvec
;     
; COMMENTS:
;     Intended as lower-level routine used by COORTRANS.PRO.
;
;-
;======================================================================
function get_rot_matrix,rot_code
;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
if (N_params() LT 1 ) then begin
    print,'Syntax: result = get_rot_matrix(rot_code)'
    return,-1
  endif
;
; Ensure we have a valid rotation code
;
rot_code = strlowcase(strtrim(rot_code,2))
if (rot_code ne 'c2e') and (rot_code ne 'e2c') and $
   (rot_code ne 'c2g') and (rot_code ne 'g2c') and $
   (rot_code ne 'g2e') and (rot_code ne 'e2g') then begin

  print,'Invalid rotation code string: ', rot_code
  return,-1
endif
;
; get a good value of pi and degrees-to-radians conversion factor
;
mypi = 3.14159265358979d0
d2r = mypi/180.d0
;
;
; establish values for rotation angles
;
  ; angle is mean obliquity of the ecliptic at J2000
  ; reference for value of obliquity of ecliptic:
  ;  Lieske etal 1977 A&A 58,1
  ;
  angle = 23.43929111d0 * d2r
  ;
  ; rotation angles for galactic/celestial conversion
  ; see j2000_coor_trans.tex
  ;
  psi   = 282.85948304067281d0 * d2r
  theta =  62.87169647216797d0 * d2r
  phi   = 327.06805887480169d0 * d2r

;
; Compute the desired rotation matrix based on angles quoted above.
;

if (rot_code eq 'c2e') or (rot_code eq 'e2c') then begin

; Compute rotation matrix for celestial to ecliptic and vice-versa
  if (rot_code eq 'c2e') then rot_matrix = rotx(angle)
  if (rot_code eq 'e2c') then rot_matrix = rotx(-angle)
;
endif else if (rot_code eq 'c2g') or (rot_code eq 'g2c') then begin
;
;
; Compute rotation matrix for equatorial to Galactic in J2000
; and vice-versa.
; references:  
;             1) Observational Astrophysics, Ch. 8 pg 397
;                Lena, Lebrun, Mignard 
;             2) Spherical Astronomy, Green 1985
;             3) ASTRO library programs EULER.PRO & JPRECESS.PRO
;

  if (rot_code eq 'c2g') then rot_matrix = rotz(psi)#rotx(theta)#rotz(phi)
  if (rot_code eq 'g2c') then rot_matrix = rotz(-phi)#rotx(-theta)#rotz(-psi)
;

endif else if (rot_code eq 'g2e') or (rot_code eq 'e2g') then begin

;
; Compute rotation matrix for ecliptic to galactic and vice-versa
; by combining rotation matrices above
;  i.e., 'g2e' = 'g2c'#'c2e'  & 'e2g' = 'e2c'#'c2g'
;

  if (rot_code eq 'e2g') then rot_matrix = $
               rotx(-angle)#rotz(psi)#rotx(theta)#rotz(phi)
  if (rot_code eq 'g2e') then rot_matrix = $
               rotz(-phi)#rotx(-theta)#rotz(-psi)#rotx(angle)
;
endif
;
return, rot_matrix
;
end







